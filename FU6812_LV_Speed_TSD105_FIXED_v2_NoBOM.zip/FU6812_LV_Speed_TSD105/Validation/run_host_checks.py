from pathlib import Path
import re,subprocess,tempfile,os
root=Path(__file__).resolve().parents[1]
def read(p):
    b=p.read_bytes()
    for e in ('utf-8-sig','gb18030'):
        try:return b.decode(e)
        except UnicodeDecodeError:pass
    raise ValueError(p)
def function(t,name):
    m=re.search(r'^void\s+'+name+r'\s*\(void\)(?:\s+interrupt\s+\d+)?',t,re.M);assert m,name
    b=t.index('{',m.end());depth=0
    for i in range(b,len(t)):
        if t[i]=='{':depth+=1
        elif t[i]=='}':
            depth-=1
            if depth==0:return re.sub(r'\binterrupt\s+\d+','',t[m.start():i+1])
    raise ValueError(name)
add=read(root/'User/Source/Application/AddFunction.c')
cmp=read(root/'User/Source/Hardware/CMPInit.c')
irq=read(root/'User/Source/Application/Interrupt.c')
mcu=read(root/'Library/FU68xx_Hardware_Driver/Include/FU68xx_2_MCU.h')
defines=''
for name in ['FOCEN','DRVOE','TSDEN','TSDADJ1','TSDADJ0']:
    m=re.search(r'^\s*#define\s+'+name+r'\s+(0x[0-9a-fA-F]+)',mcu,re.M);assert m,name
    defines+='#define '+name+' '+m[1]+'\n'
prefix=r'''
#include <stdint.h>
#include <assert.h>
#include <stdio.h>
#include <stdlib.h>
typedef uint8_t uint8;
typedef uint16_t uint16;
typedef int16_t int16;
typedef int32_t int32;
#define xdata
#include "Customer.h"
#include "Parameter.h"
#undef LV_BOARD_POWER_STAGE_VERIFIED
static uint8 test_drive_permission;
#define LV_BOARD_POWER_STAGE_VERIFIED test_drive_permission
#define SetBit(r,b) ((r)|=(b))
#define ClrBit(r,b) ((r)&=(uint8)~(b))
enum {mcInit,mcStop,mcRun,mcFault};
enum {FaultNoSource=0,FaultStall=6,FaultThrottleFault=9,FaultOverTemp=11};
static struct {int16 mcSpeedVSP,mcIqref;uint8 MotorONOFFStatus,FlagmcBrake,
 LockedFlag,mcBlackOffStopFlag,RackOffRedayFlag,LockedEnbleFlag,
 FreeStopDecStatus,mcStopMode;}mcFocCtrl;
static struct {uint16 HallSpeed;uint8 HallDirectStartStatus;}mcHall;
static struct {int16 RampStep;}SpeedRamp;
static uint8 MOE,DRV_CR,mcFaultSource,mcState;
static int16 FOC__UQ;
static volatile uint8 McuOverTempLatched;
static volatile uint8 speedHallEdges;
static uint8 TSDIE,TSDIF,EA,PTSD1,PTSD0,EVT_FILT,tsd_adj_reg;
#define TSD_ADJ tsd_adj_reg
'''
suffix=r'''
static void ticks(int n,int edges) {
 while(n--) {if(edges)++speedHallEdges; Speed_response();ONOFFControl();}
}
static void release_input(void) {mcFocCtrl.mcSpeedVSP=0;ticks(60,0);}
static void start(int16 input) {
 mcFocCtrl.mcSpeedVSP=input;ticks(30,1);
 assert(mcFocCtrl.MotorONOFFStatus && mcState==mcInit);
 mcState=mcRun;MOE=1;
}
static void settle(int16 input,double load,int expected) {
 double plant=mcHall.HallSpeed;int i;
 mcFocCtrl.mcSpeedVSP=input;
 for(i=0;i<15000;i++) {
  mcHall.HallSpeed=(uint16)plant;ticks(1,1);
  assert(FOC__UQ>=0 && FOC__UQ<=QOUTMAX);
  plant+=(FOC__UQ-load-plant)*0.005;
  if(plant<0)plant=0;
 }
 assert(abs((int)plant-expected)<100);
}
int main(void) {
 unsigned int e,t,enabled;
 assert(HW_ADC_REF==5.0 && MAXPWMDuty<1.0 && ProtecMaxPWMDuty<1.0);
 mcState=mcRun;MOE=1;DRV_CR=255;mcFocCtrl.MotorONOFFStatus=1;
 mcFocCtrl.mcSpeedVSP=SPEED_INPUT_MAX;
 test_drive_permission=0;ticks(10,1);
 assert(!MOE && !(DRV_CR&(FOCEN|DRVOE)) && !mcFocCtrl.MotorONOFFStatus);
 test_drive_permission=1;ticks(600,0);
 assert(!MOE && !mcFocCtrl.MotorONOFFStatus);
 release_input();start(SPEED_INPUT_MIN);
 settle(SPEED_INPUT_MIN,0,SPEED_TARGET_MIN);
 settle(_Q15(2.25/HW_ADC_REF),0,_Q15(2250.0/MOTOR_SPEED_BASE));
 settle(SPEED_INPUT_MAX,0,SPEED_TARGET_MAX);
 settle(SPEED_INPUT_MAX,2000,SPEED_TARGET_MAX);
 release_input();assert(!MOE && FOC__UQ==0 && mcState==mcStop);
 start(SPEED_INPUT_MIN);mcHall.HallSpeed=10000;ticks(2001,0);
 assert(!MOE && mcFaultSource==FaultStall && mcState==mcRun);
 ticks(100,0);assert(mcFaultSource==FaultStall);
 mcFaultSource=FaultNoSource;mcState=mcStop;ticks(20,0);
 assert(!mcFocCtrl.MotorONOFFStatus);
 release_input();start(SPEED_INPUT_MIN);
 mcFocCtrl.FlagmcBrake=1;ticks(1,1);assert(!MOE);
 mcFocCtrl.FlagmcBrake=0;ticks(20,1);assert(!mcFocCtrl.MotorONOFFStatus);
 release_input();start(SPEED_INPUT_MIN);
 mcFocCtrl.mcSpeedVSP=SPEED_INPUT_FAULT+1;ticks(1,1);
 assert(!MOE && mcFaultSource==FaultThrottleFault);
 for(enabled=0;enabled<2;enabled++)
 for(e=0;e<256;e++)for(t=0;t<256;t++) {
  EVT_FILT=e;tsd_adj_reg=t;EA=enabled;McuTsd_Init();
  assert(EA==enabled && EVT_FILT==((e&31)|128));
  assert(tsd_adj_reg==(t&252) && TSDIE && PTSD0 && PTSD1 && !TSDIF);
 }
 mcFaultSource=FaultNoSource;MOE=1;DRV_CR=255;TSDIF=1;
 mcFocCtrl.MotorONOFFStatus=1;TSD_INT();
 assert(!MOE && !(DRV_CR&FOCEN) && McuOverTempLatched);
 assert(mcState==mcFault && mcFaultSource==FaultOverTemp && !TSDIE && !TSDIF);
 mcFaultSource=FaultNoSource;ticks(100,1);
 assert(!MOE && !mcFocCtrl.MotorONOFFStatus && McuOverTempLatched);
 puts("PASS: default output inhibit; input endpoints/midpoint; reference ramp; simulated load; output bounds; held-input startup; restart; no fault auto-clear; lost Hall edges; 131072 TSD register combinations; overtemperature latch");
 return 0;
}
'''
source=prefix+defines+'\n'.join(function(text,name) for text,name in [
 (add,'Speed_response'),(add,'ONOFFControl'),(cmp,'McuTsd_Init'),(irq,'TSD_INT')])+suffix
with tempfile.TemporaryDirectory() as d:
    work=Path(d);(work/'check.c').write_text(source)
    subprocess.run(['gcc','-std=gnu89','-Wall','-Wextra','-Werror',
      '-Wdeclaration-after-statement','-fsanitize=undefined,address','-g',
      '-I'+str(root/'User/Include'),str(work/'check.c'),'-o',str(work/'check')],check=True)
    env=dict(os.environ);env['ASAN_OPTIONS']='detect_leaks=0'
    subprocess.run([str(work/'check')],check=True,env=env)
