/**************************** (C) COPYRIGHT 2017 Fortiortech shenzhen *****************************
* File Name          : main.c
* Author             : Fortiortech Appliction Team
* Version            : V1.0
* Date               : 2017-12-27
* Description        : This file contains main function used for Motor Control.
***************************************************************************************************
* All Rights Reserved
**************************************************************************************************/

/* Includes -------------------------------------------------------------------------------------*/
// #include <main.h>
#include <FU68xx_2.h>
#include <Myproject.h>
#include <Customer_Debug.h>

/* Private typedef ------------------------------------------------------------------------------*/
/* Private define -------------------------------------------------------------------------------*/
/* Private macro --------------------------------------------------------------------------------*/
/* Private variables ----------------------------------------------------------------------------*/
/* Private function prototypes ------------------------------------------------------------------*/
/* Private functions ----------------------------------------------------------------------------*/
void SoftwareInit(void);
void HardwareInit(void);
void DebugSet(void);
void MotorControlInit(void);

/*-------------------------------------------------------------------------------------------------
        Function Name : void main(void)
        Description   : 主函数主要功能是初始化，包括上电等待，软件初始化，硬件初始化，调试模式设置，主循环扫描。
                                    软件初始化--初始化所有定义的变量
                                    硬件初始化--初始化硬件设备配置
                                    调试模式设置--调试模式
        Input         : 无
        Output        : 无
-------------------------------------------------------------------------------------------------*/
void main(void)
{  
	static uint16 s_BrakeDelayTime =1000;
	
	  uint16 PowerUpCnt = 0;
	
		uint8 PowerUpFlag = 0;
		mcFocCtrl.mcSpeedVSP = 0;
//		static uint16 LeadAngleDownTimeDelayCnt =0;

    for(PowerUpCnt=0;PowerUpCnt<SystemPowerUpTime;PowerUpCnt++){};

    /*Software Init*/
    SoftwareInit();

    /*Hardware Init*/
    HardwareInit();
					
    /*调试模式设置--内部变量查询；CMP输出查询；ADC触发信号查询*/
//    DebugSet();
						
//		while(s_BrakeDelayTime--);
		mcState = mcInit;

    while(1)
    {			/* TSDF表示当前过温；软件标志用于保持故障 */
    if (McuOverTempLatched || ReadBit(LVSR, TSDF))
    {
        McuOverTempLatched = 1;

        MOE = 0;
        ClrBit(DRV_CR, FOCEN);

        mcFocCtrl.MotorONOFFStatus = 0;
        mcFaultSource = FaultOverTemp;
        mcState = mcFault;

        continue;  /* 不再执行电机启动、运行状态机 */
    }

#if !LV_BOARD_POWER_STAGE_VERIFIED
        /* Control-side inspection only; do not run motor state transitions. */
        MOE = 0;
        ClrBit(DRV_CR, FOCEN | DRVOE);
        mcFocCtrl.MotorONOFFStatus = 0;
        mcState = mcStop;
        continue;
#endif
				if(mcCurOffset.OffsetFlag==0)
				{ 													
					GetCurrentOffset();      // 电流偏置的获取
				}
							
				if(mcCurOffset.OffsetFlag>=1)
				{						
					MC_Control();           // 主控函数，状态扫描 
																			
					FOC_DMAX 			= DOUTMAX;
					FOC_DMIN 			= DOUTMIN;
										
					/******************配置选择  档位百分比*********************/ 	 				
//					mcFocCtrl.MSPPWMDuty  = MSPPWMDuty_48V;
//					mcFocCtrl.MIDSPWMDuty = MIDSPWMDuty_48V;
//					mcFocCtrl.LSPPWMDuty  = LSPPWMDuty_48V;
//					
//					mcFocCtrl.VOPEN_MSP_K	  = VOPEN_MSP_K_48V;		
//					mcFocCtrl.VOPEN_MIDSP_K = VOPEN_MIDSP_K_48V;
//					mcFocCtrl.VOPEN_LSP_K   = VOPEN_LSP_K_48V;					
				}	
    }
}


/*-------------------------------------------------------------------------------------------------
        Function Name : void DebugSet(void)
        Description   : 调试模式配置
        Input         : 无
        Output        : 无
-------------------------------------------------------------------------------------------------*/
void DebugSet(void)
{
	  #if (SPI_DBG_HW)      // 硬件调试模式
        Set_DBG_DMA(&HARD_SPIDATA);
    #elif (SPI_DBG_SW)    // 软件调试模式
        Set_DBG_DMA(spidebug);
    #endif

    #if  ((SPI_DBG_HW) && (SPI_DBG_SW))
        #error Only one DBG mode can be selected
    #endif

    SetReg(CMP_CR3, DBGSEL0 | DBGSEL1,  GP01_DBG_Conf);
    SetReg(CMP_CR3, CMPSEL0 | CMPSEL1 | CMPSEL2, GP07_DBG_Conf);
}

/*-------------------------------------------------------------------------------------------------
        Function Name : void SoftwareInit(void)
        Description   : 软件初始化，初始化所有定义变量，按键初始化扫描
        Input         : 无
        Output        : 无
-------------------------------------------------------------------------------------------------*/
void SoftwareInit(void)
{
    /****初始化所有定义的参数变量****/
    MotorcontrolInit();

	  ClrBit(DRV_CR, FOCEN);         // 关闭FOC
	
    MOE			= 0;                   // 关闭MOE
	
    mcState = mcStop;
	
		mcFocCtrl.mcStopMode = MotorStopMode;
	
    mcFaultSource = 0;
}


/*-------------------------------------------------------------------------------------------------
        Function Name : void HardwareInit(void)
        Description   : 硬件初始化，初始化需要使用的硬件设备配置，FOC必须配置的是运放电压、运放初始化、ADC初始化、Driver初始化
                                    TIM4初始化，其他的可根据实际需求加。
        Input         : 无
        Output        : 无
-------------------------------------------------------------------------------------------------*/
void HardwareInit(void)
{
    // 为提高芯片的抗干扰能力，降低芯片功耗，请在具体项目时，将不需要用的GPIO默认都配置为输入上拉。
    // 具体配置可在GPIO_Default_Init设置。
    GPIO_Default_Init();
	
    /******硬件FO过流，比较器初始化，用于硬件过流比较保护******/
//    #if (HardwareCurrent_Protect == Hardware_FO_Protect)  //外部中断初始化，用于外部中断硬件过流FO的保护
////        EXTI_Init();
//    #elif (HardwareCurrent_Protect == Hardware_CMP_Protect)//选择比较过流，比较器初始化
//        CMP3_Init();
//    #elif (HardwareCurrent_Protect == Hardware_FO_CMP_Protect)    //两者都选择
////        EXTI_Init();
//        CMP3_Init();
//    #endif
//	
	
//	  CMP3_Init();   //选择比较器3
		/* Original CMP3 path is not wired as this board's CMP0 protection. */
#if LV_BOARD_POWER_STAGE_VERIFIED
        CMP3_Init1();
#endif
//		EXTIIO_Init();  //外部中断初始化
	
    //  Sleepmode_Init();

    /****功能IO初始化***********/
    GPIO_Init();

    /*****运算放大器初始化*********/
    AMP_Init();

    /*****ADC初始化*********/
    ADC_Init1();
		
    /****比较器中断配置***********/
//    CMP3_Inter_Init1();                         // 建议和比较器初始化间隔一段时间

    /*****Driver初始化*********/
    Driver_Init();
#if !LV_BOARD_POWER_STAGE_VERIFIED
    MOE = 0;
    ClrBit(DRV_CR, FOCEN | DRVOE);
#endif
		

		TIM1_Init();

    /*****Timer初始化*******/
    TIM2_Init();//端口GP07 & GP10
		
    TIM3_Init();//端口GP11,采样定时器3中断作为PWM捕获中断

    TIM4_Init();//端口GP01
		
    TIM4ms_Init();//采用1ms定时器中断作为常见中断,处理故障保护等附加功能
		


	  /******************配置选择档位百分比***********/ 		
		mcFocCtrl.MSPPWMDuty  = MSPPWMDuty_48V;
		mcFocCtrl.MIDSPWMDuty = MIDSPWMDuty_48V;
		mcFocCtrl.LSPPWMDuty  = LSPPWMDuty_48V;
		
		mcFocCtrl.VOPEN_MSP_K	  = VOPEN_MSP_K_48V;		
		mcFocCtrl.VOPEN_MIDSP_K = VOPEN_MIDSP_K_48V;
		mcFocCtrl.VOPEN_LSP_K   = VOPEN_LSP_K_48V;
		/************************************************/
		
		mcHall.GivenFRStatus          = SetDirection;// ~RollBack;    		//初始化方向
				
		if(mcHall.GivenFRStatus==1)            // 设置F/R
		{
			SetBit(DRV_CR,DDIR);
		}
		else
		{
			ClrBit(DRV_CR,DDIR);
		}
				
		if(mcHall.GivenFRStatus == CW) 
		{
			mcHall.StartAngleOffset   = StartAngleCW;
		}
		else if(mcHall.GivenFRStatus == CCW) 
		{
			mcHall.StartAngleOffset   = StartAngleCCW;
		}
		McuTsd_Init();
 }
