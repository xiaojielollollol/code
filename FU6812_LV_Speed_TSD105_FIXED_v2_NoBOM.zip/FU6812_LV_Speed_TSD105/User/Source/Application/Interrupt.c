/**************************** (C) COPYRIGHT 2017 Fortiortech shenzhen *****************************
* File Name          : Interrupt.c
* Author             : Fortiortech  Appliction Team
* Version            : V1.0
* Date               : 2017-12-26
* Description        : This file contains all the interrupt function used for Motor Control.
***************************************************************************************************
* All Rights Reserved
**************************************************************************************************/


/* Includes -------------------------------------------------------------------------------------*/
// #include <Interrupt.h>
#include <FU68xx_2.h>
#include <Myproject.h>
#include <Customer_Debug.h>
uint16 xdata spidebug[4] = { 0 };
uint8 Add_LimitCurrentime = 0;
uint16 delay_time = 0;

/*-------------------------------------------------------------------------------------------------
    Function Name : void FO_INT(void)
    Description   : FO_INT interrupt，硬件FO过流保护，关断输出，中断优先级最高
    Input         : 无
		Output        : 无
-------------------------------------------------------------------------------------------------*/
void FO_INT(void) interrupt 1                                                   // 硬件FO过流中断，关闭输出
{
//    FaultProcess();                                                           // 关闭输出
    mcFaultSource = FaultHardOVCurrent;                                       // 硬件过流保护
//    mcState       = mcFault;                                                  // 状态为mcFault
    IF0           = 0;                                                          // clear P00 interrupt flag
}


/*-------------------------------------------------------------------------------------------------
    Function Name : void INT1(void)
    Description   : 外部中断1，用于检测HALL信号
    Input         : 无
		Output        : 无
-------------------------------------------------------------------------------------------------*/
void INT1(void) interrupt 2                                                  
{
	if(ReadBit(P1_IF, P15)||(ReadBit(P1_IF, P11))||(ReadBit(P1_IF, P10)))
	{					
		ClrBit(P1_IF, P15);
		ClrBit(P1_IF, P11);
		ClrBit(P1_IF, P10);
  }                                            
}

/*-------------------------------------------------------------------------------------------------
    Function Name : void TIM1_INT(void)
    Description   : 
										
    Input         : 无
		Output        : 无
-------------------------------------------------------------------------------------------------*/
void TIM1_INT(void) interrupt 5
{
	if(ReadBit(TIM1_SR,T1PDIF))
	{
		uint8  Temp_HallFR;
				
		static uint8 HallCommutationCnt = 0;
					
		static uint8 LockedDutyFLag = 0;
			
		static uint8 LockedFlag = 0;
		
		HallStatus_CaptureFilter();                               //采集Hall信号      
		
		if(!mcFocCtrl.LockedEnbleFlag)  
		{
			if((mcHall.HallStatus_Result==7)||(mcHall.HallStatus_Result==0))
			{								
//				mcBreakDowm.BreakDowmValue = 3;	
//				
//				FaultProcess();	
//				
//				mcFaultSource = FaulHallFailure;
			}
			else
			{
				if((mcState == mcFault)&&(mcFaultSource == FaulHallFailure))
				{
					mcBreakDowm.BreakDowmValue = 0;
					
					mcState = mcStop;
					
					mcFaultSource = FaultNoSource;
				}				
			}
		}
				
			mcHall.HallStatusAfterLocked = 0;
			
			if(mcHall.LastHallStatus==0)
			{
				mcHall.LastHallStatus = mcHall.HallStatus_Result;
											
				mcHall.HallFRStatus = 1;
			}
	
			if((mcHall.HallCommutationCount >= 1)||(mcState == mcStop))
			{
				 if((mcHall.LastHallStatus != mcHall.HallStatus_Result)&&(mcHall.HallStatus_Result != 0))
				 {								 
					 #if (FGEnable)
					 {
						 #if (FG_Mode == FG_FrequencyConversion_Speed)      
						 {
								FG=~FG;   
						 }					 
						 #endif
					 }
					 #endif
					 				 					 
					 if(mcHall.HallCommutationCnt<=6)
					 {
						mcHall.HallCommutationCnt++;
					 }
						 
					if(mcHall.HallCommutationCount < 60000)
					{
						mcHall.HallCommutationCount++;
					}	
															 
					 if(mcHall.HallFRStatus!=0)
					 {
						 Temp_HallFR = mcHall.HallFRStatus;   
					 }
						
					//判断电机运行方向，1为初始化设定方向，2位初始化方向的反方向
					 mcHall.HallFRStatus = HallStatus_Check(mcHall.GivenFRStatus,mcHall.LastHallStatus,mcHall.HallStatus_Result);
													 
					 if(mcHall.HallFRStatus==1)
					 {
							mcHall.HallFRreverse  =0; 
					 }
					 else if(mcHall.HallFRStatus==2)
					 {
						 mcHall.HallFRreverse ++;
						 
						 if(mcHall.HallFRreverse>=2)
						 {
								mcHall.HallFRreverse =2;
						 }
					 }
						 
					 if(Temp_HallFR != mcHall.HallFRStatus)	
					 {
						 mcHall.HallFRChange      = 1;    //反转
					 }
					 else
					 {
						 mcHall.HallFRChange      = 2;    //正转
					 }
													 
						//角度和角速度计算，处理
						HallTimeCapture(); 
											
						mcHall.LastHallStatus = mcHall.HallStatus_Result;												
				 }		 
			}
			
		ClrBit(TIM1_SR, T1PDIF);
	}
	
	
	if(ReadBit(TIM1_SR,T1BOIF))
	{
//		GP06 =~GP06;
		
		TIM1__BCNTR = 0;
		ClrBit(TIM1_SR,T1BOIF);
  }	
}

/*-------------------------------------------------------------------------------------------------
    Function Name : void CMP_ISR(void)
    Description   : CMP3：硬件比较器过流保护，关断输出，中断优先级最高
										CMP0/1/2：顺逆风判断
    Input         : 无
		Output        : 无
-------------------------------------------------------------------------------------------------*/
void CMP_ISR(void) interrupt 7
{
    if(ReadBit(CMP_SR, CMP3IF))
    {
//        if(mcState!=mcPosiCheck)
//        {
            FaultProcess();                                                     // 关闭输出
            mcFaultSource=FaultHardOVCurrent;                                   // 硬件过流保护
            mcState = mcFault;                                                  // 状态为mcFault
//        }
//        else
//        {
//            MOE     = 0;                                                                        // 关闭MOE
//            RPDPara.InsetCount[RPDPara.injecttimes]  = TIM2__CNTR;                              // 将定时器2的计数值赋值给数组
//            RPDPara.DetectCount[RPDPara.injecttimes] = RPDPara.InsetCount[RPDPara.injecttimes]; // 两组数据，一组用于观察原始数据，一组用于处理数据
//            TIM2__CNTR                               = 0;                                       // TIM2计数器值清零
//            RPDPara.injecttimes++;                                                              // RPD注入拍数累加
//        }
        ClrBit(CMP_SR, CMP3IF);
    }
		
}

/*---------------------------------------------------------------------------*/
/* Name     :   void TIM2_INT(void) interrupt 4
/* Input    :   NO
/* Output   :   NO
/* Description:	
/*---------------------------------------------------------------------------*/
static uint16 TempLPFCurrentBUS =0;

void TIM2_INT(void) interrupt 4
{	
	if(ReadBit(TIM2_CR1, T2IR))
	{
			ClrBit(TIM2_CR1, T2IR);
	}
	
	if(ReadBit(TIM2_CR1, T2IP))
	{
			ClrBit(TIM2_CR1, T2IP);
	}
	
	if(ReadBit(TIM2_CR1, T2IF))                          //溢出中断,时间为60us。
	{									
		mcFocCtrl.mcADCProtectCurrentbus =(ADC4_DR<<3);  //母线电流采样，用于软件过流
									
		if((mcHall.HALLHACWCCWTime > 200)||(mcHall.HALLHBCWCCWTime > 200)||(mcHall.HALLHCCWCCWTime >200)) 
		{
			mcHall.HallSpeed	= 0;
			
			mcFocCtrl.FreeStopDecStatus = 0;
					
			mcHall.HallSpeedInitStatus         = 0;			
		}
																	
		ClrBit(TIM2_CR1, T2IF);
	}
}

/*---------------------------------------------------------------------------*/
/* Name     :   void TIM23_INT(void) interrupt 9
/* Input    :   NO
/* Output   :   NO
/* Description: Capture PWM ，中断优先级第二，高于FOC中断，用于PWM调速
/*---------------------------------------------------------------------------*/
void TIM3_INT(void) interrupt 9
{
    if(ReadBit(TIM3_CR1, T3IR))
    {
       ClrBit(TIM3_CR1, T3IR);
    }
		
    if(ReadBit(TIM3_CR1, T3IP))//周期中断
    {
       ClrBit(TIM3_CR1, T3IP);
    }
		
    if(ReadBit(TIM3_CR1, T3IF))
    {
			SetBit(ADC_CR, ADCBSY);          //使能ADC的DCBUS采样		
								
			#if (!RMSCurrentLimitEnable)
				{	
					mcFocCtrl.mcADCCurrentbus =(ADC2_DR<<3);// LPFFunction((ADC4_DR<<3),mcFocCtrl.mcADCCurrentbus,30);
				}
				#endif
				
				/***********平均电流限流************/
				#if (RMSCurrentLimitEnable)
				{				
					TempLPFCurrentBUS = (ADC3_DR<<3);//LPFFunction((ADC5_DR<<3),TempLPFCurrentBUS,100);//127 25  100
								
					if(TempLPFCurrentBUS >= mcCurOffset.Iw_busOffset)
					{
						TempLPFCurrentBUS = TempLPFCurrentBUS - mcCurOffset.Iw_busOffset;// mcCurOffset.Iw_busOffset;	
					}
					else
					{
						TempLPFCurrentBUS = 0;					
					}
					
					mcFocCtrl.mcADCCurrentbus = TempLPFCurrentBUS;	
																	
					if(!mcHall.HallDirectStartStatus) 
					{
						RMSCurrentLimit();
					}
				}
				#endif

        ClrBit(TIM3_CR1, T3IF);
    }
}
/*---------------------------------------------------------------------------*/
/* Name     :   void FOC_INT(void) interrupt 3
/* Input    :   NO
/* Output   :   NO
/* Description: FOC中断(Drv中断),每个载波周期执行一次，用于处理响应较高的程序，中断优先级第二。DCEN开了就会产生中断。
/*---------------------------------------------------------------------------*/
void FOC_INT(void) interrupt 3
{
		static uint16 TempH =0;
	
		static uint8 TempLastHall =0;
	
    if(ReadBit(DRV_SR, DCIF))                                 // 比较中断
    {																
//				if((((!mcFocCtrl.LockedEnbleFlag))||(mcFocCtrl.FreeStopDecStatus))) //角度限制  8.2us
//				{
//				 //角度限制
//						Hall_THETA_Limit(mcHall.HallFRChange,mcHall.HallFRStatus,mcHall.NextSectorAngle,mcHall.HallSpeed,50);			 			  			
//				}	
//		 	 
////       Fault_Overcurrent(&mcCurVarible);                     // 软件过流保护.约30us
//					
//        #if defined (SPI_DBG_SW)	//软件调试模式
//            spidebug[0] = FOC__IA; //FOC__THETA;// mcHall.AngleCompensate*20;//mcFocCtrl.mcADCCurrentbus*2;//mcHall.HallStatus_Result * 4000;//SOFT_SPIDATA0;	
//            spidebug[1] = FOC__IB;//mcHall.HallStatus_Result*5000;//mcFocCtrl.RMSLimitTargetCurrent*2;//SOFT_SPIDATA1; mcState SpeedRamp.RampInc
//            spidebug[2] = mcFocCtrl.RMSLimitCurrentFlag*32767;//FOC__RTHESTEP*10;//mcFocCtrl.RMSLimitCurrentFlag*32767;//ADC10_DR<<3;                       //mcHall.HallStatus_Result*5000;//SOFT_SPIDATA2;
//            spidebug[3] = mcFocCtrl.FCCFlag*32767;
//        #endif
//			
        ClrBit(DRV_SR, DCIF);
    }
}


/*---------------------------------------------------------------------------*/
/* Name     :   void TIM4S_INT(void) interrupt 10
/* Input    :   NO
/* Output   :   NO
/* Description: 1ms定时器中断（SYS TICK中断），用于处理附加功能，如控制环路响应、各种保护等。中断优先级低于FO中断和FOC中断。
/*---------------------------------------------------------------------------*/
void TIM4S_INT(void) interrupt 10
{
	  static speed = 0;
	
	  if(ReadBit(TIM4_CR1, T4IF))
    {					
      ClrBit(TIM4_CR1, T4IF);
    }
				
    if(ReadBit(DRV_SR, SYSTIF))          // SYS TICK中断
    {		
//			static int16 TempLPFCurrentBUS = 0;
			
//			SetBit(ADC_CR, ADCBSY);          //使能ADC的DCBUS采样
			
			if((mcHall.HallCommutationCount >= 1)||(mcState == mcStop))
			{
				MDUAPP1();
			}
						
			SpeedRamp.SPEEDRampCnt ++;
			
			SpeedRamp.VoltageRampCnt++;
			
			if(SpeedRamp.VoltageRampCnt>=2000)
			{
				SpeedRamp.VoltageRampCnt =2000;
      }
											
				/*****环路响应，如速度环、转矩环、功率环等******/
        Speed_response();  
			
//			    if(speed < 10000)
//					{
//							speed  = 10000 ;	
//					}		
//					if(speed<25000)
//					{
//						speed += 1;
//					}
//					
//  				FOC__UQ = speed;
			
        /*****DCbus的采样获取值并滤波******/
				mcFocCtrl.mcADCVoltagebus =
    LPFFunction((ADC3_DR << 3),
                mcFocCtrl.mcADCVoltagebus, 120);//低通滤波
				
				if((mcState == mcStop)&&(MOE ==0)||(SpeedRamp.VoltageRampCnt<1000))
				{			
					mcFocCtrl.RampVoltage = mcFocCtrl.mcADCVoltagebus;				
				}
				
				/*****调速信号采集******/
				mcFocCtrl.mcSpeedVSP =
    LPFFunction((ADC2_DR << 3),
                mcFocCtrl.mcSpeedVSP, 50);//低通滤波
//				mcFocCtrl.mcSpeedVSP = 32760;											

        /**********************电机状态机的时序处理***************************/
        if(mcFocCtrl.State_Count > 0)    mcFocCtrl.State_Count--;
//        if(BEMFDetect.BEMFTimeCount > 0) BEMFDetect.BEMFTimeCount--;
        if(RSDDetect.RSDCCWSBRCnt > 0)     RSDDetect.RSDCCWSBRCnt--;
						
        ClrBit(DRV_SR, SYSTIF);                                    // 清零标志位
    }
}
void TSD_INT(void) interrupt 11
{
    /* 第一时间关闭输出和FOC */
    MOE = 0;
    ClrBit(DRV_CR, FOCEN);

    /* 记录并锁定过温故障 */
    McuOverTempLatched = 1;
    mcFocCtrl.MotorONOFFStatus = 0;
    mcFaultSource = FaultOverTemp;
    mcState = mcFault;

    /* 锁定后不重复进入温度中断 */
    TSDIE = 0;
    TSDIF = 0;
}









