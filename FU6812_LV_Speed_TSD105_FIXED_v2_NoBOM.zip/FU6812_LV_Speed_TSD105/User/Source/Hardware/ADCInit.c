/**************************** (C) COPYRIGHT 2017 Fortiortech shenzhen *****************************
* File Name          : ADCInit.c
* Author             : Vina Peng,Fortiortech  Appliction Team
* Version            : V1.0
* Date               : 10-Apr-2017
* Description        : This file contains ADC function used for Motor Control.
***************************************************************************************************
* All Rights Reserved
**************************************************************************************************/


/* Includes -------------------------------------------------------------------------------------*/
#include <FU68xx_2.h>
#include <Myproject.h>
#include <FU68xx_2_System.h>

/*-------------------------------------------------------------------------------------------------
	Function Name :	void ADC_Init(void)
	Description   :	ADC硬件设备初始化配置，使能ADC，通道配置，采样时间配置，中断配置
	Input         :	无
  Output				:	无
-------------------------------------------------------------------------------------------------*/
void ADC_Init(void)
{
  uint16 ADCVREF_DelayCnt;
	
 /* ADC参考电压配置*/
  VREFConfig(VREF5_0, Enable);								             // ADC参考电压配置
	
	ClrBit(P3_AN, P35);                                       //送出给P3.5的VREF电压，P3.5需外接电容，1送出，0不送出
  
/*-------------------------------------------------------------------------------------------------
	ADC基本配置
-------------------------------------------------------------------------------------------------*/
	SetBit(ADC_CR, ADCEN);		                               // 使能ADC
                                   
/*-------------------------------------------------------------------------------------------------
	ADC参考电压选择
	使能VREF，用于给ADC提供内部参考基准
  P3.5配置模拟IO，VREFEN为1-内部参考电压提供给ADC，如P3_AN为1，同时送出给P3.5的VREF电压;
	P3.5配置模拟IO，VREFEN为0-外部参考电压提供给ADC，需外部提供ADC参考。
-------------------------------------------------------------------------------------------------*/
	SetBit(VREF_VHALF_CR, VREFEN);                                        //使能VREF
  
  for(ADCVREF_DelayCnt=0;ADCVREF_DelayCnt<2000;ADCVREF_DelayCnt++){};		//等待VREF稳定
      
/*-------------------------------------------------------------------------------------------------
	ADC通道配置
  1、使能相应Pin为模拟Pin，禁止数字功能
	2、使能通道MASK，连接Pin到ADC模块
  ADC_CH0--P20_AN--IU--固定                 ADC_CH5--P32_AN
  ADC_CH1--P23_AN--IV--固定                 ADC_CH6--P33_AN
  ADC_CH2--P24_AN--DCBUS--固定              ADC_CH7--P34_AN
  ADC_CH3--P25_AN--VSP                      ADC_CH8--P21_AN
  ADC_CH4--P27_AN--IBUS/IW--固定            ADC_CH9--P16_AN
                                            ADC_CH10--P14_AN
                                            ADC_CH11--P15_AN
-------------------------------------------------------------------------------------------------*/	
////	ClrBit(P3_OE, P33);	
////	ClrBit(P3_PU, P33);
//		
//	ClrBit(P3_OE, P34);	
////	SetBit(P3_PU, P34);
////  GP34 = 0;		
//		
//	ClrBit(P2_OE, P20);
//	ClrBit(P2_OE, P21);	
//	ClrBit(P2_OE, P23);
//	ClrBit(P2_OE, P24);
//	ClrBit(P2_OE, P25);
//	ClrBit(P2_OE, P27);
//	
//	ClrBit(P3_OE, P32);	
////	ClrBit(P3_OE, P33);	
//	ClrBit(P3_OE, P34);
//	
////	SetBit(P2_PU, P21);
////	GP21 = 0;
//	
////	ClrBit(P1_OE, P16);	
////	SetBit(P1_PU, P16);
////	GP16 = 0;
////	
//	ClrBit(P1_OE, P14);	
////	SetBit(P1_PU, P14);
////	GP14 = 0;
//	
//	ClrBit(P1_OE, P15);	
////	SetBit(P1_PU, P15);
////	GP15 = 0;

//	SetBit(P1_OE, P16);

	SetBit(P3_AN, P32|P33|P34);
	
	SetBit(P1_AN, P14|P16 );
		
	SetBit(P2_AN, P27|P23|P21|P20);
	/*母线电压采样*/
	SetBit(P2_AN, P25);
	
	/*电位器调速*/
	SetBit(P2_AN, P25);
	
	/*AMP and CMP*/	
	SetBit(ADC_MASK_SYSC, CH10EN |CH6EN |CH5EN |CH4EN | CH3EN | CH2EN | CH1EN | CH0EN);		        //Config P2.7 as ADC4 IBUS/IW

	/*其他采样口*/
	SetBit(ADC_MASK_SYSC, CH6EN |CH5EN );	
	
/*ADC通道采样时钟周期设置*/
//	SetBit(ADC_MASK_SYSC, 0x3000);
	
	ADC_SYSC  = 0x333;	
	
	SetReg(ADC_CR, ADCIF|ADCIE,0x00);                   // 清标志位和关中断
	
	PADC1 =0;  //ADC中断优先级设置为0
	PADC0 =0;

	EA = 1;	
}

void ADC_Init1(void)
{
    /*  -------------------------------------------------------------------------------------------------
        ADC基本配置
        -------------------------------------------------------------------------------------------------*/
    SetBit(ADC_CR, ADCEN);                                                          // 使能ADC

    /*  -------------------------------------------------------------------------------------------------
        1、ADC通道配置
        2、使能相应Pin为模拟Pin，禁止数字功能
        3、使能通道MASK，连接Pin到ADC模块
        4、ADC_CH0--P20_AN--IU--固定                 ADC_CH5--P32_AN
        5、ADC_CH1--P23_AN--IV--固定                 ADC_CH6--P33_AN
        6、ADC_CH2--P24_AN--DCBUS--固定              ADC_CH7--P34_AN
        7、ADC_CH3--P25_AN--VSP                      ADC_CH8--P21_AN
        8、ADC_CH4--P27_AN--IBUS/IW--固定            ADC_CH9--P16_AN
                                                 ADC_CH10--P14_AN
                                                 ADC_CH11--P15_AN
        -------------------------------------------------------------------------------------------------*/
    ClrBit(P3_AN, P34); /* P3.4 is TX on this board; speed input is ADC2/P2.4. */
    
    SetBit(P2_AN, P27 | P25 | P24 | P23 | P20);
    
    SetBit(ADC_MASK_SYSC, CH7EN | CH4EN | CH3EN | CH2EN | CH1EN | CH0EN);   //Config P2.7 as ADC4 IBUS/IW
    
    /* -----ADC通道采样时钟周期设置----- */
    SetBit(ADC_MASK_SYSC, 0x3000);
    
    ADC_SYSC  = 0x33;
    
    SetReg(ADC_CR, ADCIF | ADCIE, 0x00);                                            // 清标志位和关中断
		SetBit(P3_AN, P35); //VREF Voltage -->P35 Output 是否输出到P35引脚，需同步配置输出
		SetBit(P3_AN, P32);//VHALF
		VREFConfig(VREF5_0, Enable);
}

