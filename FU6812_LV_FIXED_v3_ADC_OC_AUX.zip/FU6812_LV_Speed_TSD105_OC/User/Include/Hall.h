
/* Define to prevent recursive inclusion --------------------------------------------------------*/
#ifndef __HALL_H_
#define __HALL_H_
 	                
#define TempHallThetaBaseOneStep				(uint32)(65535.0/6.0*TIM4_Fre/SAMP_FREQ)
#define TempHallSpeedBaseOneStep				(uint32)(32767.0/6.0*(TIM4_Fre*60/Pole_Pairs/MOTOR_SPEED_BASE))

#define TempHallThetaBase								(uint32)(65535.0*TIM4_Fre/SAMP_FREQ)
#define TempHallSpeedBase							  (uint32)(32767.0*(TIM4_Fre*60/Pole_Pairs/MOTOR_SPEED_BASE))//ʵ�ʵ����е�ٶ�

typedef struct
{
	uint8   HallStatus_Filter1;
	uint8   HallStatus_Filter2;

	uint8   HallStatus_Result;
	uint8   HallStatusAfterLocked;
	uint8   HallStep;
	

	uint8   LastHallStatus;
	uint8 	HallStatus_Next;
	uint8		GivenFRStatus;
	uint8		HallFRStatus;
	uint8   FlagSpeedCal;
	uint8   BackoffFlag;
	uint8   RackoffMode;
	
	uint32	HallThetaBase;		
	uint32	HallSpeedBase;
//	int32  	SoftHallThetaBase;	//		
//	int16  	SoftRTheStep;				//��ʱ���ۼӵĽǶ�����
	uint8 MDUCountCnt;
	
	uint8 MDUCountFlag;
	
  int16	  RTheStep;

	uint16	HallSpeed;

	uint16 Last_VSP_Speed;
	
	uint16  LastHallSpeed;
	
	uint16 HallCommutationCount;
	
	uint16 HallCommutationCnt;
	
	uint16 Focemohall;
	
	uint8  HallFRChange;
	
	uint8 HallFRreverse;
		
	int16 	HallAngle;               //�����Ƕ�
	int16		NextSectorAngle;			  //��һ�����ĽǶ�

	int16 	Angle;									//FOCʹ�õĽǶ�
	uint16   AngleCompensate;
	int16   AngleLeadOffset;        //���غ�ĽǶ�����ֵ
	int16	  StartAngleOffset;				//����ʱ�Ƕ�����
		
	uint8		HallDirectStartStatus;	
	
	uint16	PeriodTime;
	uint16	MC_StepTime[6];
	
	uint16	StepTimeCount;
	
	uint8		HallSpeedInitStatus;
	
	uint8 LockedFlag;
	uint8 HALLLockStatus;
	uint8  mcFallWarningSignal;
	uint16 mcStallTimeCnt;
	uint16 HALLLockHATime;
	uint16 HALLLockHBTime;
	uint16 HALLLockHCTime;
	uint16 HALLHACWCCWTime;
	uint16 HALLHBCWCCWTime;
	uint16 HALLHCCWCCWTime;
	
	int16 Theta;

}mcHall_TypeDef;


extern int16 xdata Hall_Angle_Arr[6];
 
extern mcHall_TypeDef idata mcHall;

extern void HallStatus_CaptureFilter(void);

extern void HallTimeCapture(void);

/* Exported functions ---------------------------------------------------------------------------*/
extern uint8 GetHallStatus(void);

extern uint8 HallCommutation(uint8 GivenFR_Status ,uint8 Hall_Status_Result);
extern void Hall2HallLess(void);
extern void HallLess2Hall(void);
  
extern void Hall_RTHESTEP_Capture(void);	
extern void Hall_THETA_Capture(void);

extern void LockedFunction(void);

#endif