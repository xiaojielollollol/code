/**************************** (C) COPYRIGHT 2017 Fortiortech shenzhen *****************************
* File Name          : PIOInit.h
* Author             : Vina Peng, Fortiortech Appliction Team
* Version            : V1.0
* Date               : 10-Apr-2017
* Description        : This file contains all the common data types used for
*                      Motor Control.
***************************************************************************************************
* All Rights Reserved
**************************************************************************************************/

/* Define to prevent recursive inclusion --------------------------------------------------------*/
#ifndef __PIOINIT_H_
#define __PIOINIT_H_


#define	   LOCKED			                  (GP06)   //�������ܽӿ�

#define   RollBack                      (GP07)   //��ת�ӿ�

#define	   MSP			                    (GP07)   //���ٵ��ӿ�

#define	   LSP			                    (GP07)   //���ٵ��ӿ�

#define	   Sp			                      (GP25)   

#define	   BRAKE			                  (GP01)    //ɲ���ӿ�

#define	   XF			                      (GP37)   //�������ӿ�

#define    FG                           (GP04)   //FG���

#define    Warning_YY                   (GP05)   //�����ź�ͨѶ�ӿ�

#define SPIncPin        GP00
#define SPDecPin        GP02
#define FRPin						GP03

#define PWMPin 					GP11

#define LEDPin			 		GP10
#define SetLEDPin				{GP10 = 1;}
#define ResetLEDPin			{GP10 = 0;}
#define LEDPinONOFF			{GP10 = ~GP10;}

#define YAOTOUPin			 		GP10
#define SetYAOTOUPin			{GP10 = 0;}
#define ResetYAOTOUPin		{GP10 = 1;}

#define FPin 				  GP04
#define SetFGPin			  {GP04 = 1;}
#define ResetFGPin		  {GP04 = 0;}
#define FPinONOFF      {GP04 = ~GP04;}

#define RDPin 				  GP00
#define SetRDPin			  {GP00 = 1;}
#define ResetRDPin		  {GP00 = 0;}

/* Exported functions ---------------------------------------------------------------------------*/
extern void GPIO_Init(void);
extern void GPIO_Default_Init(void);
#endif