/**************************** (C) COPYRIGHT 2017 Fortiortech shenzhen *****************************
* File Name          : EXTIInit.h
* Author             : Vina Peng, Fortiortech Appliction Team
* Version            : V1.0
* Date               : 10-Apr-2017
* Description        : This file contains all the common data types used for
*                      Motor Control.
***************************************************************************************************
* All Rights Reserved
**************************************************************************************************/

/* Define to prevent recursive inclusion --------------------------------------------------------*/
#ifndef __EXTIINIT_H_
#define __EXTIINIT_H_

//#if (HallMode == HallIC)

#define	H_A			GP02  //02  36
#define	H_B			GP37  //37  37
#define	H_C			GP36  //36  02

#if (HallSequence==1)
 	#define	HALLA			H_A
 	#define	HALLB			H_B
 	#define	HALLC			H_C
#elif (HallSequence==2)
 	#define	HALLA			H_A
 	#define	HALLB			H_C
 	#define	HALLC	  	H_B
#elif (HallSequence==3)
 	#define	HALLA			H_B
 	#define	HALLB		  H_A
 	#define	HALLC			H_C
#elif (HallSequence==4)
 	#define	HALLA			H_C
 	#define	HALLB			H_A
 	#define	HALLC		H_B
#elif (HallSequence==5)
 	#define	HALLA			H_C
 	#define	HALLB			H_B
 	#define	HALLC			H_A
#elif (HallSequence==6)
 	#define	HALLA			H_B
 	#define	HALLB			H_C
 	#define	HALLC			H_A
#endif


//#elif (HallMode == HallSensor)
//	#define	HA	ReadBit(CMP_SR, CMP0_OUT)
//	#define	HB	ReadBit(CMP_SR, CMP1_OUT)
//	#define	HC	ReadBit(CMP_SR, CMP2_OUT)

//#endif

/* Exported functions ---------------------------------------------------------------------------*/
extern void EXTI_Init(void);
extern void EXTIIO_Init(void);
extern void Sleepmode_Init(void);

#endif


