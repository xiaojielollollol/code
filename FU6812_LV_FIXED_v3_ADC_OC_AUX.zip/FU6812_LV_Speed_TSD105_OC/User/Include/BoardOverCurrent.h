#ifndef BOARD_OVERCURRENT_H
#define BOARD_OVERCURRENT_H

/* Auxiliary software protection only. ADC10 observes the raw shunt voltage;
 * no amplifier gain or 2.5V offset belongs in this conversion.
 * ADC conversion and CPU service add latency; this is NOT a short-circuit
 * hardware shutdown path and does not authorize power-stage operation.
 */
#define BOARD_OC_TRIP_A       (60.3)
#define BOARD_OC_SHUNT_OHM    (0.015)
#define BOARD_OC_TRIP_RAW     ((uint16)(BOARD_OC_TRIP_A * BOARD_OC_SHUNT_OHM * 4095.0 / HW_ADC_REF + 0.5))
#define BOARD_OC_ADC_TIMEOUT_CALLS (16)

extern volatile uint8 xdata BoardOverCurrentLatched;
extern volatile uint8 xdata BoardOcFaultCode;
extern volatile uint8 xdata BoardOcAdcReady;
extern volatile uint16 xdata BoardOcAdcRaw;

/* Called from one context only: FOC_INT, once per DRV DCIF event. */
extern void BoardOc_Service(void);

#endif
