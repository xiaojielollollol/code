/**************************** (C) COPYRIGHT 2017 Fortiortech shenzhen *****************************
* File Name          : Customer.h
* Author             : Fortiortech Appliction Team
* Version            : V1.0
* Date               : 2017-12-21
* Description        : This file contains all the common data types used for
*                      Motor Control.
***************************************************************************************************
* All Rights Reserved
**************************************************************************************************/

/* Define to prevent recursive inclusion --------------------------------------------------------*/
#ifndef __CUSTOMER_H_
#define __CUSTOMER_H_

/*芯片参数值-------------------------------------------------------------------*/
/*CPU and PWM Parameter*/
#define MCU_CLOCK                      (24.0)                                  // (MHz) 主频
#define PWM_FREQUENCY                  (16.0)                                  // (kHz) 载波频率

/*deadtime Parameter*/
#define PWM_DEADTIME                   (1.4)                                   // (us) 死区时间

/*single resistor sample Parameter*/
#define MIN_WIND_TIME                  (0)                                    // (us) 单电阻最小采样窗口，建议值死区时间+0.9us

/*电机参数值-------------------------------------------------------------------*/
#define Pole_Pairs                     (4)                                     // 极对数

#define LD                             (0.0008343*1.0)                          // (H) D轴电感  (有感FOC不需要改动)
#define LQ                             (LD)                          // (H) Q轴电感  (有感FOC不需要改动)

#define RS                             (1.197)                                // (Ω) 相电阻   (有感FOC不需要改动)

#define KeVpp                          (7.28*0.45)                             // (V)      反电动势测量的峰峰值  (有感FOC不需要改动)
#define KeT                            (31.1)                                  // (ms)     反电动势测量的周期  (有感FOC不需要改动)
#define Ke                             (Pole_Pairs * KeVpp * KeT / 207.84)		 // (V/KRPM) 反电动势常数

#define MOTOR_SPEED_BASE               (5000.0)                                // (RPM) 速度基准

/*硬件板子参数设置值------------------------------------------------------------*/
/*PWM high or low level Mode*/
/*根据驱动芯片的类型选择，大部分芯片为High_Level*/
#define High_Level                     (0)                                     // 驱动高电平有效
#define Low_Level                      (1)                                     // 驱动低电平有效
#define UP_H_DOWN_L                    (2)                                     // 上桥臂高电平有效，下桥臂低电平有效
#define UP_L_DOWN_H                    (3)                                     // 上桥臂低电平有效，下桥臂高电平有效
#define PWM_Level_Mode                 (High_Level)

/*hardware current sample Parameter*/
/*电流基准的电路参数*/                                             //250913未改
//**********运放1、运放2放大倍数以及相电流采样电阻参数设置		
#define 	HW_RSHUNT										(0.015)							
#define 	HW_AMPGAIN									(15.0)													

//**********运放0放大倍数以及母线电流采样电阻参数设置
#define 	HW_RSHUNT0									(0.015)		
#define 	HW_AMPGAIN0									(15.0)	

#define   HW_ADC_REF                  (5.0)                                     // (V)  ADC参考电压

/*hardware voltage sample Parameter*/
/*母线电压采样分压电路参数*/                                         //250913未改
#define RV1                            (30.0)                                  // (kΩ) 母线电压分压电阻1
#define RV2                            (0.0)                                   // (kΩ) 母线电压分压电阻2
#define RV3                            (4.7)                                   // (kΩ) 母线电压分压电阻3
#define VC1                            (1.0)                                   // 电压补偿系数
#define RV                             ((RV1 + RV2 + RV3) / RV3)               // 分压比
#define HW_BOARD_VOLT_MAX              (HW_ADC_REF * RV)                       // (V)  ADC可测得的最大母线电压

/*电流采样模式*/
#define Single_Resistor                (0)                                     // 单电阻电流采样模式
#define Double_Resistor                (1)                                     // 双电阻电流采样模式
#define Three_Resistor                 (2)                                     // 三电阻电流采样模式
#define Shunt_Resistor_Mode            (Double_Resistor)

//电流设置                                                           //250913未改
#if (Shunt_Resistor_Mode == Single_Resistor)
/***启动电流****/
#define IQ_Start_CURRENT               I_Value_Single_Resistor(0.1)                            // (A) Q轴启动电流

/***运行电流****/
#define IQ_RUN_CURRENT                 I_Value_Single_Resistor(0.2)                            // (A) Q轴运行电流
#define IQ_RUN_MAX_CURRENT             I_Value_Single_Resistor(80)                            // (A) Q轴最大运行电流

#elif (Shunt_Resistor_Mode == Double_Resistor)
/***启动电流****/
#define ID_Start_CURRENT               I_Value_Double_Resistor(0.0)                            // (A) D轴启动电流
#define IQ_Start_CURRENT               I_Value_Double_Resistor(0.8)                            // (A) Q轴启动电流

/***运行电流****/
#define IQ_RUN_CURRENT                 I_Value_Double_Resistor(0.8)                           // (A) Q轴运行电流
#define IQ_RUN_MAX_CURRENT             I_Value_Double_Resistor(10.0)                          // (A) Q轴最大运行电流

#endif

/* current set value */
#define 	I_Value_Single_Resistor(Curr_Value)					_Q15(((Curr_Value*HW_RSHUNT0*HW_AMPGAIN0)/(HW_ADC_REF)))    //Unit in A
#define 	I_Value_Double_Resistor(Curr_Value)					_Q15(((Curr_Value*HW_RSHUNT*HW_AMPGAIN)/(HW_ADC_REF)))      //Unit in A
#define 	I_ValueRC(Curr_Value)				                _Q15(((Curr_Value*HW_RSHUNT0*HW_AMPGAIN0)/(HW_ADC_REF)))    //Unit in A
#define   I_ValueX(Curr_Value)                        _Q7(((Curr_Value * HW_RSHUNT0 * HW_AMPGAIN0  + 2.5)*2/ HW_ADC_REF))

/*--------使能均值限流功能需要硬件电路支持，即需要将运放0输出经过RC滤波，再用AD采样该信号作处理---------------*/
/*---------均值限流的RC参数：R = 10K ,C =10nf-------------*/
#define   RMSCurrentLimitEnable       (0)                                     //使能均值限流，1使能，0不使能
#define 	IQ_RUN_MAX_RMS_CURRENT			I_ValueRC(10.0)													// 最大均值限流值，A
#define 	IQ_RUN_MIN_RMS_CURRENT			I_ValueRC(1.0)													// 最小均值限流值，A
#define 	IQ_RMSlIMIT_K		    (float)((float)(IQ_RUN_MAX_RMS_CURRENT-IQ_RUN_MIN_RMS_CURRENT)/(float)(_Q15(MAXPWMDuty)-_Q15(ONPWMDuty))) 

/*电流环参数设置值--------------------------------------------------------------*/
#define DQKP                           _Q12(0.08)                              // DQ轴KP
#define DQKI                           _Q15(0.01)                              // DQ轴KI

/* D轴参数设置 */
#define DOUTMAX                        _Q15(0.2)                              // D轴最大限幅值，单位：输出占空比
#define DOUTMIN                        _Q15(-0.2)                             // D轴最小限幅值，单位：输出占空比

/* Q轴参数设置，默认0.99即可 */
//双电阻QOUTMAX<=_Q15(0.90)
#define QOUTMAX                        _Q15(0.90)                              // Q轴最大限幅值，单位：输出占空比
#define QOUTMIN                        _Q15(-0.90)                             // Q轴最小限幅值，单位：输出占空比

/*********电机开机、关机设置------------------------------------------------------*/
#define 	OFFPWMDuty	    						(0.45 / HW_ADC_REF)		                                 //关机电平，当电平小于（OFFPWMDuty*HW_ADC_REF）关机
#define 	ONPWMDuty	      						(0.50 / HW_ADC_REF)	                                 //开机电平，当电平大于（ONPWMDuty*HW_ADC_REF）开机       
#define 	MAXPWMDuty	    						(4.00 / HW_ADC_REF)                                    //最大有效调速电平，当电平大于（MAXPWMDuty*HW_ADC_REF），维持最大输出力矩
#define   ProtecMinPWMDuty   				  (0.00)                                    //最小保护电平，当调速电平小于于（ProtecMinPWMDuty*HW_ADC_REF），关机
#define   ProtecMaxPWMDuty   					(4.40 / HW_ADC_REF)                                    //最大保护电平，当调速电平大于（ProtecMaxPWMDuty*HW_ADC_REF），关机

//档位占空比设置 
#define   GearControlEnable            (0)                                    //分档调速使能，1使能，0不使能
#define   MSPPWMDuty_48V              QOUTMAX                                 //最高档占空比设置
#define   MIDSPWMDuty_48V             QOUTMAX                                 //中档占空比设置
#define   LSPPWMDuty_48V              QOUTMAX                                 //低档占空比设置

#define   BackOffPWMDuty           _Q15(0.30)                                 //倒车占空比设置

#define 	VOPEN_MIDSP_K_48V		     (((float)((float)(MIDSPWMDuty_48V-MinPWMDuty)/(float)(_Q15(MAXPWMDuty)-_Q15(ONPWMDuty))))*64) 
#define 	VOPEN_MSP_K_48V		       (((float)((float)(MSPPWMDuty_48V-MinPWMDuty)/(float)(_Q15(MAXPWMDuty)-_Q15(ONPWMDuty))))*64) 
#define 	VOPEN_LSP_K_48V		       (((float)((float)(LSPPWMDuty_48V-MinPWMDuty)/(float)(_Q15(MAXPWMDuty)-_Q15(ONPWMDuty))))*64) 

#define 	VOPEN_BACKOFF_K		       (((float)((float)(BackOffPWMDuty-MinPWMDuty)/(float)(_Q15(MAXPWMDuty)-_Q15(ONPWMDuty))))*64) 
		 
#define		MinPWMDuty									_Q15(0.05)                               //最小PWM运行占空比
#define		StartPWMDuty								_Q15(0.1)                                //启动占空比

/*********停机模式------------------------------------------------------*/
#define   FreeStop										(0)																	 //自由停止
#define   SlowStop                    (1)                                  //慢停止
#define   MotorStopMode							(FreeStop)													 

/*********刹车模式------------------------------------------------------*/
#define  QuickBrakeStop   						(2)																	 //快速刹车停止
#define  SlowBrakeStop                (3)                                  //慢速刹车停止
#define  BrakeMode                  (SlowBrakeStop)                       
                          
/*********刹车使能------------------------------------------------------*/
#define  BrakeEnable                   (0)                                    //刹车使能，1使能，0不使能     

/*********方向设置------------------------------------------------------*/
#define CW                              (0)
#define CCW                             (1)
#define SetDirection                    (CW)                                 //方向选择

/*----------------------------------------Hall传感器排列序列------------------------------------------------------------*/
#define HallSequence                      (1)                 //霍尔顺序1~6 

/*----------------------------------------Hall传感器安装模式------------------------------------------------------------*/
#define StartAngleCW                      _Q15(30.0/180.0)                  //CW方向的启动角度
#define StartAngleCCW                     _Q15(-30.0/180.0)                 //CCW方向的启动角度

/*Hall安装与反电动势的关系*/
#define HallAdvanceBEMF30Degree						(0)											          //Hall超前反电动势30°
#define HallSameWithBEMF									(1)											          //Hall与反电动势重合
#define HallDelayBEMF30Degree							(2)											          //Hall滞后反电动势30°
#define	HallAndBEMF										    (HallDelayBEMF30Degree)           //Hall安装模式选择

#define HallInverseEnable									(0)											          // Hall信号是否反相

#if   (HallAndBEMF == HallAdvanceBEMF30Degree)
#define	AngleOffsetCW											(-30.0)	                          // CW方向的偏移角度，单位：度   标准 -30°
#define AngleOffsetCCW										(-90.0)			          	          // CCCW方向的偏移角度，单位：度 标准 -90°

#elif (HallAndBEMF == HallSameWithBEMF)
#define	AngleOffsetCW											(0.0)	                            // CW方向的偏移角度，单位：度  标准 0°
#define AngleOffsetCCW										(-60.0)			          	          // CCW方向的偏移角度，单位：度 标准 -60°

#elif (HallAndBEMF == HallDelayBEMF30Degree)
#define	AngleOffsetCW											(30.0)	                          //CW方向的偏移角度，单位：度   标准 30°  
#define AngleOffsetCCW										(-30.0)			                      //CCW方向的偏移角度，单位：度  标准 -30° 

#endif

#define TempAngleOffsetCW							    _Q15(AngleOffsetCW/180.0)
#define TempAngleOffsetCCW							  _Q15(AngleOffsetCCW/180.0)

#define TempAfterLoadAngleOffsetCCW       _Q15(AfterLoadAngleOffsetCCW/180.0)
#define TempAfterLoadFrontAngleOffsetCCW  _Q15(AfterLoadFrontAngleOffsetCCW/180.0)

#define TempDeitaFrontAngleCCW             _Q15((AngleOffsetCCW-AfterLoadFrontAngleOffsetCCW)/180.0)
#define TempDeitaAngleCCW                  _Q15((AngleOffsetCCW-AfterLoadLastAngleOffsetCCW)/180.0)

/*speed loop mode*/ 
#define   Voltage_Loop_Enable            (1)                                     // 电压环控制
#define 	Speed_Loop_Mode                (Voltage_Loop_Enable)

#if (Speed_Loop_Mode == Voltage_Loop_Enable)
/***********************电压环参数设置**************************************/          
#define 	VKP													_Q12(0.1)																// Voltage loop KP
#define 	VKI													_Q12(0.01)															// Voltage loop KI

#if (Shunt_Resistor_Mode == Single_Resistor)
	#define 	SOUTMAX										I_Value_Single_Resistor(120.0)			  // Voltage loop output max value
	#define 	SOUTMIN										I_Value_Single_Resistor(0.001)					// Voltage loop output min value
#elif (Shunt_Resistor_Mode == Double_Resistor)
	#define 	SOUTMAX										I_Value_Double_Resistor(120.0)		    // Voltage loop output max value
	#define 	SOUTMIN										I_Value_Double_Resistor(0.001)					// Voltage loop output min value
#endif

#define   SPEEDRampTIME               (10)     //环路作用周期，单位ms  
#define 	Duty_INC										(50)	   //正常爬坡增量																    
#define 	Duty_SoftStart_INC					(10)		 //软启动爬坡增量														    
#define 	Duty_DEC										(20)	   //爬坡减量

#endif
 
/*开环启动模式选择*/                                           //250913未改
#define Open_Start                     (0)                                     // 开环强拖启动
#define Omega_Start                    (1)                                     // Omega启动
#define Open_Omega_Start               (2)                                     // 先开环启，后Omega启动
#define Open_Start_Mode                (Open_Start)

#define OverModulation                 (0)                                     // 0-禁止过调制，1-使能过调制

/*保护参数值-------------------------------------------------------------------*/              //250913未改
/*硬件过流保护*/
#define Hardware_FO_Protect            (1)                                     // 硬件FO过流保护使能，适用于IPM有FO保护的场合
#define Hardware_CMP_Protect           (2)                                     // 硬件CMP比较过流保护使能，适用于MOS管应用场合
#define Hardware_FO_CMP_Protect        (3)                                     // 硬件CMP比较和FO过流保护都使能
#define Hardware_Protect_Disable       (4)                                     // 硬件过流保护禁止，用于测试
#define HardwareCurrent_Protect        (Hardware_CMP_Protect)                  // 硬件过流保护实现方式

/*硬件过流保护比较值来源*/
#define Compare_DAC                    (0)                                     // DAC设置硬件过流值
#define Compare_Hardware               (1)                                     // 硬件设置硬件过流值
#define Compare_Mode                   (Compare_DAC)                           // 硬件过流值的来源

#define OverHardcurrentValue           (80.0)                                   // (A) DAC模式下的硬件过流值 有2.5V偏置的设定

/*软件过流保护*/
#if (Shunt_Resistor_Mode == Single_Resistor)
	#define OverSoftCurrentValue           I_Value_Single_Resistor(150.0)        // (A) 软件过流值
#elif (Shunt_Resistor_Mode == Double_Resistor)
	#define OverSoftCurrentValue           I_Value_Double_Resistor(150.0)        // (A) 软件过流值
#endif

/*过流恢复*/
#define CurrentRecoverEnable           (0)                                     // 过流保护使能位, 0，不使能；1，使能
#define OverCurrentRecoverTime         (1000)                                  // (ms) 过流保护恢复时间

#define StartProtectEnable             (0)                                     // 启动保护，0,不使能；1，使能
#define PhaseLossProtectEnable         (0)                                     // 缺相保护，0,不使能；1，使能

/*过欠压保护*/
#define VoltageProtectEnable           (1)                                     // 电压保护，0,不使能；1，使能
#define VoltageProtectRecoverEnble     (0)                                     // 电压保护恢复使能，0，不使能，1使能
#define Over_Protect_Voltage           (35.0)                                    // (V) 直流电压过压保护值
#define Over_Recover_Vlotage           (34.0)                                    // (V) 直流电压过压保护恢复值
#define Under_Protect_Voltage          (15.0)                                    // (V) 直流电压欠压保护值
#define Under_Recover_Vlotage          (16.5)                                    // (V) 直流电压欠压保护恢复值

/*缺相保护*/
#define PhaseLossCurrentValue          I_Value(0.2)                            // (A)  缺相电流值
#define PhaseLossRecoverTime           (600)                                   // (ms) 缺相保护时间

/*堵转保护*/
#define 	StallProtectEnable				  (0)														           // 堵转保护使能，1使能，0不使能
#define   StallDetectTime						  (2000)															     // 堵转保护监测时间，单位ms
#define   StallTime                   (1500)                                   // 堵转保护时间，单位ms
#define   StallMINPWMDuty             _Q15(0.10)                               // 堵转保护最小占空比
/* 速度闭环参数 */
#define SPEED_INPUT_MIN    _Q15(0.50 / HW_ADC_REF)
#define SPEED_INPUT_MAX    _Q15(4.00 / HW_ADC_REF)
#define SPEED_INPUT_STOP   _Q15(0.45 / HW_ADC_REF)
#define SPEED_INPUT_FAULT  _Q15(4.40 / HW_ADC_REF)

#define SPEED_TARGET_MIN   _Q15(500.0  / MOTOR_SPEED_BASE)
#define SPEED_TARGET_MAX   _Q15(4000.0 / MOTOR_SPEED_BASE)

/* 每10ms变化约10rpm，约1000rpm/s */
#define SPEED_RAMP_STEP    _Q15(10.0 / MOTOR_SPEED_BASE)

/* 初始调试值，必须按实际电机整定 */
#define SPEED_KP_Q12       (4096)  /* Kp = 1.0 */
#define SPEED_KI_Q12       (82)    /* Ki约0.02/次，每10ms一次 */
/* Inspection build for the fixed-wiring low-voltage board.
 * Keep 0 until hardware FOC current routing and fast overcurrent shutdown
 * are reviewed and verified. This is NOT a DEMO-board configuration.
 */
#define LV_BOARD_POWER_STAGE_VERIFIED (0)
#endif
