/**************************** (C) COPYRIGHT 2017 Fortiortech shenzhen *****************************
* File Name          : CMPInit.c
* Author             : Vina Peng,Fortiortech  Appliction Team
* Version            : V1.0
* Date               : 10-Apr-2017
* Description        : This file contains CMP initial function used for Motor Control.
***************************************************************************************************
* All Rights Reserved
**************************************************************************************************/


/* Includes -------------------------------------------------------------------------------------*/
#include <FU68xx_2.h>
#include <Myproject.h>

/*-------------------------------------------------------------------------------------------------
	Function Name :	void CMP3_Iint(void)
	Description   :	比较器3初始化,用于硬件过流保护
	Input         :	无
  Output				:	无
-------------------------------------------------------------------------------------------------*/
void CMP3_Init(void)
{
#if LV_BOARD_POWER_STAGE_VERIFIED

	#if (Shunt_Resistor_Mode == Single_Resistor)
	{
		SetBit(P2_AN, P27);	                               // CMP3

  	SetReg(CMP_CR1, CMP3MOD1|CMP3MOD0,0x00);
	}
	#elif (Shunt_Resistor_Mode == Double_Resistor)    //会进这个
	{
		SetBit(P2_AN, P27);	                               // CMP3
    SetReg(CMP_CR1, CMP3MOD1|CMP3MOD0,0x00);
	}
	#elif (Shunt_Resistor_Mode == Three_Resistor)
	{
		SetBit(P2_AN, P27 | P23 | P20);	                               // CMP3
		SetReg(CMP_CR1, CMP3MOD1|CMP3MOD0,CMP3MOD1|CMP3MOD0);
	}
	#endif	//end Shunt_Resistor_Mode
	
  #if (Compare_Mode == Compare_Hardware)
	{
    /**P2.6使能其模拟功能，使能数字输出**/
    SetBit(P2_AN, P26);
    SetBit(P2_OE, P26); 
    ClrBit(DAC_CR,DACEN);
  }
  #else                                           //会进这个
  {      				
		SetBit(P2_AN, P26);
    SetBit(P2_OE, P26); 
		
    /**********使能DAC******************/
    SetBit(DAC_CR, DACEN );
    /******************************
    0: 正常模式，DAC输出电压范围为0到VREF，适用于硬件过流保护
    1: 半电压转换模式，DAC输出电压范围为VHALF到VREF
    ****************************/
    ClrBit(DAC_CR, DACMOD );
    /**********设置DAC过流值*****************/
    DAC_DR = DAC_OvercurrentValue;
  }
  #endif	//end Compare_Mode

	SetBit(CMP_CR1, CMP3HYS);                            // 比较器3有迟滞电压

/*-------------------------------------------------------------------------------------------------
	选择母线电流保护触发信号源，外部中断0或者比较器3中断。
	 1-INT0, 0-CMP3
-------------------------------------------------------------------------------------------------*/
	ClrBit(EVT_FILT, EFSRC);
	
/*-------------------------------------------------------------------------------------------------
	触发硬件保护后硬件关闭驱动输出MOE配置
	00--MOE不自动清零
	01--MOE自动清零
-------------------------------------------------------------------------------------------------*/
	SetReg(EVT_FILT, MOEMD0 | MOEMD1, MOEMD0);
//  SetReg(EVT_FILT, MOEMD0 | MOEMD1, 0x00);
/*-------------------------------------------------------------------------------------------------
	  母线电流保护时间滤波宽度
	  00-不滤波    01-4cpu clock    10-8cpu clock    11-16cpu clock
-------------------------------------------------------------------------------------------------*/
	SetBit(EVT_FILT, EFDIV1);
	SetBit(EVT_FILT, EFDIV0);

	

/*比较器使能-------------------------------------------------------------------------------------*/
	SetBit(CMP_CR1, CMP3EN);

#else
    MOE = 0;
    ClrBit(DRV_CR, FOCEN);
#endif
}

void CMP3_Inter_Init(void)
{
  /*-------------------------------------------------------------------------------------------------
	比较器中断模式配置
	00: 不产生中断  01: 上升沿产生中断  10: 下降沿产生中断  11: 上升/下降沿产生中断
-------------------------------------------------------------------------------------------------*/
	ClrBit(CMP_SR, CMP3IF);
	SetReg(CMP_CR0, CMP3IM1 | CMP3IM0, CMP3IM0);

	PCMP1 = 1;
	PCMP0 = 1;									                             // 中断优先级别3

  EA = 1;
}


/*  -------------------------------------------------------------------------------------------------
    Function Name  : CMP3_Init
    Description    : 比较器3初始化,用于硬件过流保护
    Date           : 2020-08-07
    Parameter      : None
    ------------------------------------------------------------------------------------------------- */
void CMP3_Init1(void)
{
#if LV_BOARD_POWER_STAGE_VERIFIED

    
    #if (Shunt_Resistor_Mode == Three_Resistor)//不会进
    {
        SetBit(P2_AN, P27 | P23 | P20);                             // CMP3
        SetReg(CMP_CR1, CMP3MOD1 | CMP3MOD0, CMP3MOD1 | CMP3MOD0);
    }
    #else //会进
    {
        SetBit(P2_AN, P27);                                         // CMP3
        SetReg(CMP_CR1, CMP3MOD1 | CMP3MOD0, 0x0);//单输入

    }
    #endif  //end Shunt_Resistor_Mode
    
    #if (Compare_Mode == Compare_Hardware)//不会进
    {
        /* -----P2.6使能其模拟功能，使能数字输出----- */
        SetBit(P2_AN, P26);
        SetBit(P2_OE, P26);
        ClrBit(DAC_CR, DACEN);
    }
    #else //会进
    {
        /* -----使能DAC----- */
        SetBit(DAC_CR, DACEN );
        /*  -------------------------------------------------------------------------------------------------
            1、DAC电压模式配置
            2、0: 正常模式，DAC输出电压范围为0到VREF，适用于硬件过流保护
            3、1: 半电压转换模式，DAC输出电压范围为VHALF到VREF
            -------------------------------------------------------------------------------------------------*/
        ClrBit(DAC_CR, DACMOD );

        
        DAC_DR = DAC_OvercurrentValue;

    }
    #endif  //end Compare_Mode
    SetBit(CMP_CR1, CMP3HYS);                                       // 比较器3有迟滞电压
    /*  -------------------------------------------------------------------------------------------------
        1、选择母线电流保护触发信号源，外部中断0或者比较器3中断。
        2、1-INT0, 0-CMP3
        -------------------------------------------------------------------------------------------------*/
    ClrBit(EVT_FILT, EFSRC);
    /*  -------------------------------------------------------------------------------------------------
        1、触发硬件保护后硬件关闭驱动输出MOE配置
        2、00--MOE不自动清零
        3、01--MOE自动清零
        -------------------------------------------------------------------------------------------------*/
    SetReg(EVT_FILT, MOEMD0 | MOEMD1, MOEMD0);
    //  SetReg(EVT_FILT, MOEMD0 | MOEMD1, 0x00);
    /*  -------------------------------------------------------------------------------------------------
        1、母线电流保护时间滤波宽度
        2、00-不滤波    01-4cpu clock    10-8cpu clock    11-16cpu clock
        -------------------------------------------------------------------------------------------------*/
    SetReg(EVT_FILT, EFDIV0 | EFDIV1, EFDIV0 | EFDIV1);
    /*比较器使能-------------------------------------------------------------------------------------*/
    SetBit(CMP_CR1, CMP3EN);

#else
    MOE = 0;
    ClrBit(DRV_CR, FOCEN);
#endif
}

/*  -------------------------------------------------------------------------------------------------
    Function Name  : CMP3_Inter_Init
    Description    : 比较器中断配置
    Date           : 2020-08-07
    Parameter      : None
    ------------------------------------------------------------------------------------------------- */
void CMP3_Inter_Init1(void)
{
    /*  -------------------------------------------------------------------------------------------------
        1、比较器中断模式配置
        2、00: 不产生中断  01: 上升沿产生中断  10: 下降沿产生中断  11: 上升/下降沿产生中断
        -------------------------------------------------------------------------------------------------*/
    ClrBit(CMP_SR, CMP3IF);
//		SetReg(CMP_CR0, CMP3IM0 , 0x1);	
//		SetReg(CMP_CR0, CMP3IM1 , 0x0);

    ClrBit(CMP_CR0, CMP3IM1);
		SetBit(CMP_CR0, CMP3IM0);
    PCMP1 = 1;
    PCMP0 = 1;                                                      // 中断优先级别3
    EA = 1;
		
}
/* 旧版头文件可能没有这个寄存器定义 */
#ifndef TSD_ADJ
#define TSD_ADJ (*((volatile uint8 xdata *)0x40F3))
#endif

void McuTsd_Init(void)
{
    uint8 savedEA;

    savedEA = EA;
    EA = 0;

    TSDIE = 0;
    ClrBit(EVT_FILT, TSDEN);

    /*
     * 标称105℃：组合编码0000。
     * 最高位：TSD_ADJ[1]
     * 中间位：EVT_FILT[6:5]
     * 最低位：TSD_ADJ[0]
     */

    /* 只清低两位，保留运放配置 */
    TSD_ADJ &= (uint8)0xFC;

    /* 只清温度档位，保留过流保护配置 */
    ClrBit(EVT_FILT, TSDADJ1 | TSDADJ0);

    TSDIF = 0;

    /* 温度中断设为最高优先级 */
    PTSD1 = 1;
    PTSD0 = 1;

    SetBit(EVT_FILT, TSDEN);
    TSDIE = 1;

    EA = savedEA;
}
