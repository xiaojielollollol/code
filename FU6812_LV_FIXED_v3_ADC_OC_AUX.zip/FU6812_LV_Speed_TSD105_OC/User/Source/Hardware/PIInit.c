
/**************************** (C) COPYRIGHT 2017 Fortiortech shenzhen *****************************
* File Name          : PIInit.c
* Author             : Fortiortech  Appliction Team
* Version            : V1.0
* Date               : 10-Apr-2017
* Description        : This file contains PI initial function used for Motor Control.
***************************************************************************************************
* All Rights Reserved
**************************************************************************************************/


/* Includes -------------------------------------------------------------------------------------*/
#include <FU68xx_2.h>
#include <Myproject.h>

void PI_Init(void)
{
//	#if (Speed_Loop_Mode == Voltage_Loop_Enable)
//	{
//		PI_KP = VKP;
//		PI_KI = VKI;
//		PI_EK = 0;
//		PI_LPF_CR |= 0x02;									// Start PI
//		PI_UKMAX = SOUTMAX;
//		PI_UKMIN = SOUTMIN;
//		_nop_(); _nop_(); _nop_(); _nop_();
//		PI_UK =   0;
//		PI_LPF_CR &= 0xFD;									// stop PI
//	}
//	#endif
		
	
		PI_KP = _Q12(2.5);
    PI_KI = Q15(0.004);
    PI_UKMAX = I_Value_Double_Resistor(22.0);
    PI_UKMIN = I_Value_Double_Resistor(0.0);
	
	  PI_UK = 0;
}