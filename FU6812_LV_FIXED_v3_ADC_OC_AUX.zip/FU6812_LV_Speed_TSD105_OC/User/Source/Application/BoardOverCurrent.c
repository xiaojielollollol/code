#include <FU68xx_2.h>
#include <Myproject.h>
#include <BoardOverCurrent.h>

volatile uint8 xdata BoardOverCurrentLatched = 0;
volatile uint8 xdata BoardOcFaultCode = FaultNoSource;
volatile uint8 xdata BoardOcAdcReady = 0;
volatile uint16 xdata BoardOcAdcRaw = 0;

static void BoardOc_Trip(uint8 reason)
{
    MOE = 0;
    ClrBit(DRV_CR, FOCEN);
    BoardOcFaultCode = reason;
    BoardOverCurrentLatched = 1;
    mcFocCtrl.MotorONOFFStatus = 0;
    mcFaultSource = reason;
    mcState = mcFault;
}

void BoardOc_Service(void)
{
    static uint8 xdata pending;
    static uint8 xdata waitCalls;

    if (BoardOverCurrentLatched)
    {
        MOE = 0;
        ClrBit(DRV_CR, FOCEN);
        return;
    }
    if (!ReadBit(ADC_CR, ADCEN))
    {
        BoardOc_Trip(FaultAdcSampleTimeout);
        return;
    }
    if (pending)
    {
        if (ReadBit(ADC_CR, ADCBSY))
        {
            if (++waitCalls >= BOARD_OC_ADC_TIMEOUT_CALLS)
                BoardOc_Trip(FaultAdcSampleTimeout);
            return;
        }
        pending = 0;
        waitCalls = 0;
        BoardOcAdcRaw = ADC10_DR & 0x0FFF;
        BoardOcAdcReady = 1;
        if (BoardOcAdcRaw >= BOARD_OC_TRIP_RAW)
        {
            BoardOc_Trip(FaultSoftOVCurrent);
            return;
        }
    }
    if (!ReadBit(ADC_CR, ADCBSY))
    {
        SetBit(ADC_CR, ADCBSY);
        pending = 1;
        waitCalls = 0;
    }
    else if (++waitCalls >= BOARD_OC_ADC_TIMEOUT_CALLS)
    {
        BoardOc_Trip(FaultAdcSampleTimeout);
    }
}
