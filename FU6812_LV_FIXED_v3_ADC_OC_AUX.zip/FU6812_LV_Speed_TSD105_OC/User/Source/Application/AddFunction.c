/**************************** (C) COPYRIGHT 2017 Fortiortech shenzhen *****************************
* File Name          : AddFunction.c
* Author             : Fortiortech  Appliction Team
* Version            : V1.0
* Date               : 2017-12-26
* Description        : This file contains all the add function used for Motor Control.
***************************************************************************************************
* All Rights Reserved
**************************************************************************************************/


/* Includes -------------------------------------------------------------------------------------*/
// #include <AddFunction.h>
#include <FU68xx_2.h>
#include <Myproject.h>
/* 每收到一次有效霍尔边沿递增 */
static volatile uint8 xdata speedHallEdges = 0;

/* MCU片内过温锁定标志：新增 */
volatile uint8 xdata McuOverTempLatched = 0;
FaultStateType xdata mcFaultSource;

/* Private variables ---------------------------------------------------------*/
/* fault storage is defined once below */
/* 每收到一次有效霍尔边沿递增 */


/* Private variables ---------------------------------------------------------*/
/* fault storage is defined once below */
PWMINPUTCAL        xdata   mcPwmInput;
FaultVarible       idata   mcFaultDect;
MotorRSDTypeDef    xdata   RSDDetect;
CurrentVarible     xdata   mcCurVarible;
ProtectVarible     xdata   mcProtectTime;
Ramp_TypeDef       xdata   SpeedRamp;

FOCCTRL            xdata   mcFocCtrl;
ADCSample          xdata   AdcSampleValue;
ONVarible          xdata   ONOFFTest;
MCLedDisplay       xdata   mcLedDisplay;
MCRAMP             xdata   mcSpeedRamp;
SLEEPMODE          xdata   SleepSet;
MotorFRTypeDef		 xdata   mcFRState;
BreakDowmVarible   xdata     mcBreakDowm;
int16 						 xdata   VSP;
uint8              Add_Flag = 0;
int16              Errow_PI = 0;
//uint16 OverLimitCurrentTimeCnt = 0;
uint8 Limit_IbusPIFlag = 0;
uint8 Limit_Flag = 0;
uint8 LImit_CoutFlag = 0;
uint8	Limit_IbusCoutFlag = 0;

/*---------------------------------------------------------------------------*/
/* Name		:	int16 KLPF_VALUE(int16 INVlaue, int16 OutLastValue)
/* Input	:	INVlaue，OutLastValue
/* Output	:	int16的变量
/* Description:	滤波函数,用乘法器做的
/*---------------------------------------------------------------------------*/
int16 KLPF_VALUE(int16 INVlaue, int16 OutLastValue)
{
	int16 Result = 0;
	MDU_MA = (INVlaue-OutLastValue);
	MDU_MB = (int16)480;		           			/*写被乘数和乘数*/

	Result = MDU_MB;
	Result += OutLastValue;
	return(Result);
}

/*---------------------------------------------------------------------------*/
/* Name		:	void FaultProcess(void)
/* Input	:	NO
/* Output	:	NO
/* Description:	保护处理函数，关闭FOC输出，同时将状态变为mcFault
/*---------------------------------------------------------------------------*/
void FaultProcess(void)
{
	MOE     = 0;
	ClrBit(DRV_CR, FOCEN);	//关闭FOC
	mcState = mcFault;

}

/*---------------------------------------------------------------------------*/
/* Name		:	int16 Abs_F16(int16 value)
/* Input	:	value
/* Output	:	int16
/* Description:	对变量取16位的绝对值
/*---------------------------------------------------------------------------*/
uint16 Abs_F16(int16 value)
{
	if(value < 0)
	{
		return (- value);
	}
	else
	{
		return (value);
	}
}


/*---------------------------------------------------------------------------*/
/* Name		:	int32 Abs_F32(int32 value)
/* Input	:	value
/* Output	:	int16
/* Description:	对变量取16位的绝对值
/*---------------------------------------------------------------------------*/
uint32 Abs_F32(int32 value)
{
	if(value < 0)
	{
		return (- value);
	}
	else
	{
		return (value);
	}
}
/*---------------------------------------------------------------------------*/
/* Name		:	void APP_DIV(void)
/* Input	:	void
/* Output	:	void
/* Description:	将所有用到除法的地方，放在同一个中断，以避免中断串扰
/*---------------------------------------------------------------------------*/
void APP_DIV(void)
{
    if( mcPwmInput.PWMDivFlag==1)  //启动除法器，避免与过调值中的除法冲突
    {
       mcPwmInput.PWMDuty = MDU_DIV_IDATA_U32(&mcPwmInput.pwm.PWMCompareAMP, &mcPwmInput.PWMARRUpdate);
       mcPwmInput.PWMDivFlag=0;
    }
    if( mcFocCtrl.ESDIVFlag==1)  //启动除法器，避免与过调值中的除法冲突
    {
       mcFocCtrl.SQUSpeedDIVEs = MDU_DIV_XDATA_U32(&mcFocCtrl.SQUSysSpeed,&mcFocCtrl.EsValue);
       mcFocCtrl.ESDIVFlag=0;
    }
}
/*---------------------------------------------------------------------------*/
/* Name		:	void PWMInputCapture(void)
/* Input	:	NO
/* Output	:	NO
/* Description:	输入PWM处理
/*---------------------------------------------------------------------------*/
void PWMInputCapture(void)
{
  uint16 MotorControlVSP;

	 if(mcPwmInput.PWMUpdateFlag==1)  // 有新的duty更新
	 {
      if((Abs_F32(mcPwmInput.PWMCompare-mcPwmInput.PWMCompareOld)<50)// 两次比较值相近，减少读错率
        &&(Abs_F32(mcPwmInput.PWMARROld-mcPwmInput.PWMARR)<50)// 两次周期值相近，减少读错率
//        &&((100<mcPwmInput.PWMARR)&&(mcPwmInput.PWMARR<6000))// 周期值在一定范围内才认为有效，即一定频率范围
        &&(mcPwmInput.PWMDivFlag==0))
        {
          mcPwmInput.PWMFlag=1;                               // PWMFlag置1期间，不读取TIM3__DR和TIM3__ARR;，防止出错
          mcPwmInput.pwm.PWMCompareUpdate[0]=(mcPwmInput.PWMCompare>>1);// 对其乘以32768
          mcPwmInput.PWMARRUpdate=mcPwmInput.PWMARR;
          mcPwmInput.PWMDivFlag=1;                            // 启动除法
          mcPwmInput.PWMFlag=0;
        }
				
       if(mcPwmInput.PWMDivFlag==0)
        {
          if(mcPwmInput.PWMcnt<3)//2次求平均值
          {
            mcPwmInput.PWMcnt++;
            mcPwmInput.PWMVSum +=mcPwmInput.PWMDuty;
          }
          else
          {
            MotorControlVSP= (mcPwmInput.PWMVSum >>1);//注意其有一个右移与前面的比较值标幺化有关
            mcPwmInput.PWMVSum=0;
            mcPwmInput.PWMcnt =0;
          }
					
         MotorControlVSP = mcPwmInput.PWMDuty;
					
//         if((MotorControlVSP > ONPWMDuty)&&(MotorControlVSP <=(OFFPWMDutyHigh+1)))
//          {
//            mcSpeedRamp.FlagONOFF = 1;
//          }
//         else if(MotorControlVSP < OFFPWMDuty)//||(MotorControlVSP >= OFFPWMDutyHigh))
//          {
//            mcSpeedRamp.FlagONOFF = 0;
//          }

          //转速曲线计算
//          if(mcSpeedRamp.FlagONOFF==1)
//          {
//            if(MotorControlVSP <= MINPWMDuty)
//            {
//              mcSpeedRamp.TargetValue = Motor_Min_Speed;
//            }
//            else if(MotorControlVSP < MAXPWMDuty)
//            {
//              mcSpeedRamp.TargetValue = Motor_Min_Speed + SPEED_K*(MotorControlVSP-MINPWMDuty);
//            }
//            else
//            {
//              mcSpeedRamp.TargetValue	=	Motor_Max_Speed;
//            }
//          }
//          else
//          {
//            mcSpeedRamp.TargetValue =0;
//          }
        }

      mcPwmInput.PWMUpdateFlag =0;
      mcPwmInput.PWMCompareOld=mcPwmInput.PWMCompare;//将此次比较值赋值给上次比较值
      mcPwmInput.PWMARROld=mcPwmInput.PWMARR;//将此次周期值赋值给上次周期值
	  }
}
/*****************************************************************************
 * Function:		 void	Fault_OverVoltage(mcFaultVarible *h_Fault)
 * Description:	 过压欠压保护函数：程序每5ms判断一次，母线电压大于过压保护值时，计数器加一，计数器值超过20次，判断为过压保护，关闭输出;反之，计数器慢慢减
                 同理，欠压保护。
	               电机过欠压保护状态下，母线电压恢复到欠压恢复值以上，过压恢复值以下时，计数器加一，超过200次后，恢复。根据档位信息来决定恢复到哪个状态。
 * Parameter:		 mcFaultVarible *h_Fault
 * Return:			 no
 *****************************************************************************/
void Fault_OverUnderVoltage(FaultVarible *h_Fault)
{
	//过压保护
		if(mcFaultSource == FaultNoSource)//程序无其他保护下
		{
				if(mcFocCtrl.mcADCVoltagebus > OVER_PROTECT_VALUE)	 //母线电压大于过压保护值时，计数，超过20次，判断为过压保护，关闭输出;反之，计数器慢慢减
				{
					h_Fault->OverVoltDetecCnt++;
					if(h_Fault->OverVoltDetecCnt > 20)//检测100ms
					{
						h_Fault->OverVoltDetecCnt = 0;
						mcFaultSource=FaultOverVoltage;
						FaultProcess();
					}
				}
				else
				{
					if(h_Fault->OverVoltDetecCnt>0)
					{
						h_Fault->OverVoltDetecCnt--;
					}
				}

			//欠压保护

				if(mcFocCtrl.mcADCVoltagebus< UNDER_PROTECT_VALUE)
				{
					h_Fault->UnderVoltDetecCnt++;

					if(h_Fault->UnderVoltDetecCnt > 20)//检测100ms
					{
						h_Fault->UnderVoltDetecCnt = 0;
						mcFaultSource=FaultUnderVoltage;
						FaultProcess();
					}
				}
				else
				{
					if(h_Fault->UnderVoltDetecCnt>0)
					{
						h_Fault->UnderVoltDetecCnt--;
					}
				}
		}

		/*******过压欠压保护恢复*********/
		#if (VoltageProtectRecoverEnble)
		{
			if((mcState == mcFault) &&((mcFaultSource==FaultUnderVoltage)||(mcFaultSource==FaultOverVoltage)))
			{
				if((mcFocCtrl.mcADCVoltagebus< OVER_RECOVER_VALUE)&&(mcFocCtrl.mcADCVoltagebus> UNDER_RECOVER_VALUE))
				{
					h_Fault->VoltRecoverCnt++;
					if(h_Fault->VoltRecoverCnt>200)//连续检测1s，若正常则恢复
					{
						mcState = mcInit;
						mcFaultSource=FaultNoSource;
						h_Fault->VoltRecoverCnt = 0;
					}
				}
				else
				{
					h_Fault->VoltRecoverCnt = 0;
				}
		 }
	 }
	 #endif
}

/*****************************************************************************
 * Function:		 void Fault_Overcurrent(CurrentVarible *h_Cur)
 * Description:	 电机运行或者启动时，当三相中某一相最大值大于OverCurrentValue，则OverCurCnt加1。
								 连续累加3次，判断为软件过流保护。执行时间约30.4us。
 * Parameter:		 mcFaultVarible *h_Fault
 * Return:			 no
 *****************************************************************************/
void Fault_Overcurrent(CurrentVarible *h_Cur)
{
	if(mcState == mcRun)//||(mcState == mcStart))						// check over current in rum and open mode
	{
		h_Cur->Abs_ia = Abs_F16(FOC__IA);
		h_Cur->Abs_ib = Abs_F16(FOC__IB);
		h_Cur->Abs_ic = Abs_F16(-FOC__IA-FOC__IB);
		
//		if(h_Cur->Abs_ia> h_Cur->Max_ia)                      // 此部分既用于软件过流保护，又用于缺相保护
//		{
//			 h_Cur->Max_ia = h_Cur->Abs_ia;
//		}
//		if(h_Cur->Abs_ib > h_Cur->Max_ib)
//		{
//			 h_Cur->Max_ib = h_Cur->Abs_ib;
//		}
//		if(h_Cur->Abs_ic > h_Cur->Max_ic)
//		{
//			 h_Cur->Max_ic = h_Cur->Abs_ic;
//		}
		
//		if((mcFocCtrl.mcADCProtectCurrentbus>=OverSoftCurrentValue)||(h_Cur->Abs_ib>=OverSoftCurrentValue)||(h_Cur->Abs_ic>=OverSoftCurrentValue))
		if(mcFocCtrl.mcADCProtectCurrentbus >= OverSoftCurrentValue)
		{
			h_Cur->OverCurCnt++;
			if(h_Cur->OverCurCnt>=3)
			{
//				h_Cur->Abs_ia=0;
//				h_Cur->Abs_ib=0;
//				h_Cur->Abs_ic=0;
				h_Cur->OverCurCnt=0;
			  mcFaultSource=FaultSoftOVCurrent;
			  FaultProcess();
			}
		}
    else
		{
			if(h_Cur->OverCurCnt>0)
			{
				h_Cur->OverCurCnt--;
			}
		}
	}
}

/*****************************************************************************
 * Function:		 void	Fault_OverCurrentRecover(mcFaultVarible *h_Fault)
 * Description:	 软硬件过流保护恢复
 * Parameter:		 mcFaultVarible *h_Fault
 * Return:			 no
 *****************************************************************************/
void Fault_OverCurrentRecover(FaultVarible *h_Fault)
{
	if((mcState == mcFault)&&((mcFaultSource==FaultSoftOVCurrent)||(mcFaultSource==FaultHardOVCurrent))&&(mcProtectTime.CurrentPretectTimes<5))
	{
		h_Fault->CurrentRecoverCnt++;
		if(h_Fault->CurrentRecoverCnt>=OverCurrentRecoverTime)//200*5=1s
		{
			h_Fault->CurrentRecoverCnt=0;
			mcProtectTime.CurrentPretectTimes++;
			mcState = mcInit;
			mcFaultSource=FaultNoSource;
    }
  }
}

/*****************************************************************************
 * Function:		 void	Fault_Start(mcFaultVarible *h_Fault)
 * Description:	 启动保护函数，电机运行状态下，电机在前5s估算转速达到堵转保护值或者5s后反电动势值太低(此方法未验证)
                  或4s内还在CtrlMode状态，即速度低于MOTOR_LOOP_RPM，程序判断为启动失败，电机停机。
                  当程序判断为启动失败后，若重启次数少于或等于5次，程序立即进入校准状态，等待重启。
 * Parameter:		 mcFaultVarible *h_Fault
 * Return:			 no
 *****************************************************************************/
//  void Fault_Start(FaultVarible *h_Fault)
//  {
//		/*******启动保护恢复*********/
////		h_Fault->mcEsValue = FOC__ESQU;

//		if(mcState == mcRun)
//		{
//			//方法一，5s内速度大于最大速度，同时反电动势值低于一定值
//			if(h_Fault->StartSpeedCnt<=1000)
//			{
//			  h_Fault->StartSpeedCnt++;
//				if((mcFocCtrl.SpeedFlt > Motor_Max_Speed)&&(mcFocCtrl.EsValue<50))
//				{
//					h_Fault->StartSpeedCnt = 0;
//					mcFaultSource=FaultStart;
//					FaultProcess();
//					mcProtectTime.SecondStartTimes++;
//					mcProtectTime.StartFlag  =  1;
//        }
//      }
//     //方法二
//			if(h_Fault->StartEsCnt<=1200)//前6s，等待1.5s后，开始判断ES，如果超过一定次数，则失败
//			{
//				h_Fault->StartEsCnt++;
//				h_Fault->StartDelay++;
//				if(h_Fault->StartDelay>=300)				// 1.5s
//				{
//					 h_Fault->StartDelay=300;
//					 if((mcFocCtrl.EsValue <5))//&&(mcFocCtrl.CtrlMode==0))
//						{
//							h_Fault->StartESCount++;
//							if(h_Fault->StartESCount>=20)
//							{
//								mcFaultSource=FaultStart;
//								FaultProcess();
//								mcProtectTime.SecondStartTimes++;
//								h_Fault->StartDelay=0;
//								h_Fault->StartESCount=0;
//								mcProtectTime.StartFlag  =  2;
//							}
//						}
//            else
//						{
//							if(h_Fault->StartESCount>0)
//								h_Fault->StartESCount--;
//						}
//			 }
//		 }
//     else
//     {
//       h_Fault->StartESCount=0;
//     }
//		 	//方法三，长时间在CtrlMode=0状态
//			if(mcFocCtrl.CtrlMode==0)         //
//			{
//				h_Fault->StartFocmode++;
//				if(h_Fault->StartFocmode>=400)
//				{
//					h_Fault->StartFocmode=0;
//					mcFaultSource=FaultStart;
//					FaultProcess();
//					mcProtectTime.SecondStartTimes++;
//          mcProtectTime.StartFlag  =  3;
//        }
//			}
//	  }

//		 if((mcFaultSource==FaultStart)&&(mcState == mcFault)&&(mcProtectTime.SecondStartTimes<=StartProtectRestartTimes))
//		 {
//			 mcFaultSource=FaultNoSource;
//			 mcState = mcInit;
//		 }
//	}


 /*****************************************************************************
 * Function:		 void	Fault_Stall(mcFaultVarible *h_Fault)
 * Description:	 堵转保护函数
 * Parameter:		 mcFaultVarible *h_Fault
 * Return:			 no
 *****************************************************************************/
//堵转保护
void Fault_Stall(FaultVarible *h_Fault)
{	
	if(!mcFocCtrl.LockedEnbleFlag)  //不锁机
	{
		if((mcState == mcRun)||(mcState == mcStart))
		{						
			if(mcHall.HALLLockStatus)
			{
				if(mcHall.mcStallTimeCnt < StallTime)
				{
					if(mcFocCtrl.mcIqref >= StallMINPWMDuty)
					{
						mcFocCtrl.mcIqref -= 80;
						FOC_IQREF = mcFocCtrl.mcIqref;
						PI_UK = mcFocCtrl.mcIqref;
					}	
				}
				else
				{
					mcHall.mcStallTimeCnt = StallTime;
					
					mcFaultSource=FaultStall;

					FaultProcess();		
				}
			} 			
		}
	}	
}

 /*****************************************************************************
 * Function:		 void	Fault_phaseloss(mcFaultVarible *h_Fault)
 * Description:	 缺相保护函数，当电机运行状态下，10ms取三相电流的最大值，
	               1.5s判断各相电流最大值，若存在两相电流值大于一定值，而第三相电流值却非常小，则判断为缺相保护，电机停机；
 * Parameter:		 mcFaultVarible *h_Fault
 * Return:			 no
 *****************************************************************************/
  void Fault_phaseloss(FaultVarible *h_Fault)
  {
//			if(mcState == mcRun)
//		 {
//				h_Fault->Lphasecnt++;
//				if(h_Fault->Lphasecnt>100)//100*5=500ms
//				{
//					 h_Fault->Lphasecnt=0;
//					 if(((mcCurVarible.Max_ia>(mcCurVarible.Max_ib*3))||(mcCurVarible.Max_ia>(mcCurVarible.Max_ic*3)))&&(mcCurVarible.Max_ia>PhaseLossCurrentValue))
//					 {
//							h_Fault->AOpencnt++;
//					 }
//					 else
//					 {
//						if(h_Fault->AOpencnt>0)
//							h_Fault->AOpencnt --;
//					 }
//					 if(((mcCurVarible.Max_ib >(mcCurVarible.Max_ia*3))||(mcCurVarible.Max_ib >(mcCurVarible.Max_ic*3)))&&(mcCurVarible.Max_ib >PhaseLossCurrentValue))
//					 {
//						 h_Fault->BOpencnt++;
//					 }
//					else
//					 {
//             if(h_Fault->BOpencnt>0)
//							h_Fault->BOpencnt --;
//					 }
//					 if(((mcCurVarible.Max_ic >(mcCurVarible.Max_ia*3))||(mcCurVarible.Max_ic >(mcCurVarible.Max_ib*3)))&&(mcCurVarible.Max_ic >PhaseLossCurrentValue))
//					 {
//						 h_Fault->COpencnt++;
//					 }
//					else
//					 {
//             if(h_Fault->COpencnt>0)
//							h_Fault->COpencnt --;
//					 }
//						mcCurVarible.Max_ia = 0;
//						mcCurVarible.Max_ib = 0;
//						mcCurVarible.Max_ic = 0;
//					if(h_Fault->AOpencnt > 1|| h_Fault->BOpencnt > 1 || h_Fault->COpencnt > 1)
//					 {
//							mcProtectTime.LossPHTimes++;
//							mcFaultSource=FaultLossPhase;
//							FaultProcess();
//					 }
//				}
//			}

  }

/*---------------------------------------------------------------------------*/
/* Name		:	void Fault_Detection(void)
/* Input	:	NO
/* Output	:	NO
/* Description:	保护函数，因保护的时间响应不会很高，采用分段处理，每5个定时器中断执行一次对应的保护
	              常见保护有过欠压、过温、堵转、启动、缺相等保护，调试时，可根据需求，一个个的调试加入。
/*---------------------------------------------------------------------------*/
void Fault_Detection(void)
{
		mcFaultDect.segment++;
		if(mcFaultDect.segment>=5)
		{
			mcFaultDect.segment=0;
		}
		if(mcFaultDect.segment==0)
			{
				if(CurrentRecoverEnable)   //过流保护恢复使能
				{
					Fault_OverCurrentRecover(&mcFaultDect);
				}
			}
		else if(mcFaultDect.segment==1)
			{
        if(VoltageProtectEnable==1) //过压保护使能
				{
	        Fault_OverUnderVoltage(&mcFaultDect);
				}
			}
		else if(mcFaultDect.segment==2)
			{
				if(StartProtectEnable==1)  //启动保护使能
				{
//			 	  Fault_Start(&mcFaultDect);
				}
      }
	  else if(mcFaultDect.segment==3)
			{
				if(StallProtectEnable==1)  //堵转保护使能
				{
				  Fault_Stall(&mcFaultDect);
				}
      }
		else if(mcFaultDect.segment==4)
			{
				if(PhaseLossProtectEnable==1)//缺相保护使能
				{
				  Fault_phaseloss(&mcFaultDect);
				}
      }
		else
			{

      }
}


/*---------------------------------------------------------------------------*/
/* Name		:	void Speed_response(void)
/* Input	:	NO
/* Output	:	NO
/* Description:	速度响应函数，可根据需求加入控制环，如恒转矩控制、恒转速控制、恒功率控制
/*---------------------------------------------------------------------------*/
void Speed_response(void)
{
	static uint16 xdata bootMs, edgeAge;
    static uint8 xdata releasedMs, onMs;
    static uint8 xdata armed, active, tick, lastEdge;
    static int16 xdata reference, lastOutput;
    static int32 xdata integral;

    int16 input, feedback, target, voltage;
    int32 delta, error, proportional;
    int32 nextIntegral, raw, ceiling;

    if (!LV_BOARD_POWER_STAGE_VERIFIED || McuOverTempLatched || BoardOverCurrentLatched)
    {
        MOE = 0;
        ClrBit(DRV_CR, FOCEN | DRVOE);
        mcFocCtrl.MotorONOFFStatus = 0;
        active = 0;
        armed = 0;
        releasedMs = 0;
        tick = 0;
        edgeAge = 0;
        lastEdge = speedHallEdges;
        integral = 0;
        FOC__UQ = 0;
        mcFocCtrl.mcIqref = 0;
        SpeedRamp.RampStep = 0;
        return;
    }
    input = mcFocCtrl.mcSpeedVSP;

    /* 上电先等待500ms，避免ADC初始零值造成误使能 */
    if (bootMs < 500)
    {
        ++bootMs;
        armed = 0;
    }
    else if (input < 0 || input > SPEED_INPUT_FAULT)
    {
        mcFaultSource = FaultThrottleFault;
    }
    else if (input <= SPEED_INPUT_STOP)
    {
        if (releasedMs < 50)
            ++releasedMs;

        if (releasedMs >= 50)
            armed = 1;
    }
    else
    {
        releasedMs = 0;
    }

    /* 故障、刹车或禁止运行后，要求重新释放输入 */
    if (mcFaultSource != FaultNoSource ||
        mcState == mcFault ||
        mcFocCtrl.FlagmcBrake ||
        mcFocCtrl.LockedFlag ||
        mcFocCtrl.mcBlackOffStopFlag ||
        mcFocCtrl.RackOffRedayFlag)
    {
        armed = 0;
        releasedMs = 0;
    }

    if (armed &&
        input >= SPEED_INPUT_MIN &&
        input <= SPEED_INPUT_FAULT)
    {
        if (onMs < 10)
            ++onMs;

        if (onMs >= 10)
            mcFocCtrl.MotorONOFFStatus = 1;
    }
    else
    {
        onMs = 0;

        if (!armed || input <= SPEED_INPUT_STOP)
            mcFocCtrl.MotorONOFFStatus = 0;
    }

    /* 停机时清除控制状态并关闭输出 */
    if (!mcFocCtrl.MotorONOFFStatus)
    {
        active = 0;
        tick = 0;
        edgeAge = 0;
        lastEdge = speedHallEdges;
        integral = 0;

        MOE = 0;
        FOC__UQ = 0;
        mcFocCtrl.mcIqref = 0;
        SpeedRamp.RampStep = 0;
        return;
    }

    /* 启动和顺风接管期间，沿用原处理 */
    if (mcState != mcRun ||
        !MOE ||
        mcHall.HallDirectStartStatus)
    {
        active = 0;
        tick = 0;
        edgeAge = 0;
        lastEdge = speedHallEdges;
        return;
    }

    /* 连续2秒没有新霍尔边沿，停机报堵转 */
    if (lastEdge != speedHallEdges)
    {
        lastEdge = speedHallEdges;
        edgeAge = 0;
    }
    else if (++edgeAge >= 2000)
    {
        mcFaultSource = FaultStall;
        mcFocCtrl.MotorONOFFStatus = 0;

        armed = 0;
        releasedMs = 0;
        active = 0;

        MOE = 0;
        FOC__UQ = 0;
        return;
    }

    feedback = mcHall.HallSpeed > 32767U
             ? 32767 : (int16)mcHall.HallSpeed;

    voltage = (int16)FOC__UQ;

    if (voltage < 0)
        voltage = 0;

    if (voltage > QOUTMAX)
        voltage = QOUTMAX;

    /* 接管时跟踪当前速度和输出 */
    if (!active)
    {
        reference = feedback;
        integral = (int32)voltage * 4096L;
        lastOutput = voltage;
        active = 1;
    }

    /* 本函数每1ms调用，PI每10ms执行一次 */
    if (++tick < 10)
        return;

    tick = 0;

    if (input < SPEED_INPUT_MIN)
        input = SPEED_INPUT_MIN;

    if (input > SPEED_INPUT_MAX)
        input = SPEED_INPUT_MAX;

    /* 0.5～4V线性对应500～4000rpm */
    target = SPEED_TARGET_MIN + (int16)(
        (int32)(input - SPEED_INPUT_MIN) *
        (SPEED_TARGET_MAX - SPEED_TARGET_MIN) /
        (SPEED_INPUT_MAX - SPEED_INPUT_MIN));

    /* 速度给定斜坡 */
    delta = (int32)target - reference;

    if (delta > SPEED_RAMP_STEP)
        delta = SPEED_RAMP_STEP;

    if (delta < -(int32)SPEED_RAMP_STEP)
        delta = -(int32)SPEED_RAMP_STEP;

    reference = (int16)(reference + delta);

    /* 软件速度PI，输出为Q轴电压 */
    error = (int32)reference - feedback;
    proportional = error * SPEED_KP_Q12;
    ceiling = (int32)QOUTMAX * 4096L;

    /* 跟踪外部限流等处理降低后的输出 */
    if (voltage < lastOutput)
        integral -=
            (int32)(lastOutput - voltage) * 4096L;

    nextIntegral = integral + error * SPEED_KI_Q12;
    raw = proportional + nextIntegral;

    /* 输出饱和时，禁止继续向饱和方向积分 */
    if (!((raw > ceiling && error > 0) ||
          (raw < 0 && error < 0)))
    {
        integral = nextIntegral;
    }

    if (integral > ceiling)
        integral = ceiling;

    if (integral < -ceiling)
        integral = -ceiling;

    raw = proportional + integral;

    if (raw > ceiling)
        raw = ceiling;

    if (raw < 0)
        raw = 0;

    lastOutput = (int16)(raw / 4096L);

    FOC__UQ = lastOutput;
    mcFocCtrl.mcIqref = lastOutput;
    SpeedRamp.RampStep = lastOutput;
}

/*---------------------------------------------------------------------------*/
/* Name		:	void FGOutput(void)
/* Input	:	NO
/* Output	:	NO
/* Description:	FG信号输出
/*---------------------------------------------------------------------------*/
void FGOutput(void)
{//FG可用中断FGIF进行判断
	if(mcState==mcRun)
	{
		if((FOC__THETA>=0)&&(FOC__THETA<32768))//0-180
		{
			ResetFGPin;
		}
		else if((FOC__THETA>=32768)&&(FOC__THETA<65536))//180-360
		{
			SetFGPin;
		}
  }
	else if(mcState == mcFault)
	{
			SetFGPin;
	}
	else
	{
			ResetFGPin;
	}
}

/*---------------------------------------------------------------------------*/
/* Name		:	 uint16 SoftLPF(uint16 Xn1, uint16 Xn0, uint16 K)
/* Input	:	uint16 Xn1, uint16 Xn0, uint16 K
/* Output	:	uint16
/* Description:	软件低通滤波
/*---------------------------------------------------------------------------*/
 int16 SoftLPF(int16 Xn1, int16 Xn0, int16 K)
 {
 	int16 Temp16 = 0;
 	int32 Temp32 = 0;

 	Temp32 = (((int32)Xn1 - (int32)Xn0) * (int32)K) >> 15;
 	Temp16 = Xn0 + (int16)Temp32;
 	return Temp16;
 }

 /*---------------------------------------------------------------------------*/
/* Name		:	void HW_Current_PI(void)
/* Input	:	NO
/* Output	:	NO
/* Description:	
/*---------------------------------------------------------------------------*/
void HW_Current_PI(int16 PIDTarget,int16 PIDRef)
{	
	PI_EK =  PIDTarget - PIDRef;	
	
	PI_LPF_CR |= 0x02;									// Start PI
	
	_nop_();
  _nop_();
  _nop_();
  _nop_();
  _nop_();
	

	mcFocCtrl.mcIqref  = PI_UK;
	FOC_IQREF = PI_UK;
		
	PI_LPF_CR &= 0xFD;									// stop PI	
}


/*-------------------------------------------------------------------------------------------------
	Function Name :	int16 HW_Genal_PI(int16 Xn1, int16 Yn0, int16 Xn2)
	U(K) = U(k-1) + Kp*(E(k)-E(k-1)) + Ki*E(k) ----- (Uk_min < U(k) < Uk_max)b
	Description   :	PI控制
	Input         :	Xn1--E(K-1)
	                Yn0--U(K-1)
					Xn2--E(K)
	Output		  :	PI_UK--当前PI输出值,执行时间为3.8us
-------------------------------------------------------------------------------------------------*/
//int16 HW_Genal_PI(int16 Xn1, int16 Yn0, int16 Xn2)
//{
//		PI_KP = SKP;
//		PI_KI = SKI;
//		PI_UKMAX = SOUTMAX;
//		PI_UKMIN = SOUTMIN;
//		PI_EK =  Xn1;     	  //初始化E(K-1)
//		PI_LPF_CR |= 0x02;	  // Start PI
//		_nop_();  _nop_();  _nop_();  _nop_();  _nop_();
//		PI_UK =  Yn0;           //初始化U(K-1)
//		PI_EK =  Xn2;	      //填入EK
//		PI_LPF_CR |= 0x02;	  // Start PI
//		_nop_();  _nop_();  _nop_();  _nop_();  _nop_();
//		PI_UK+=(SKP/4096 +1);
//		return PI_UK;
//}
/*-------------------------------------------------------------------------------------------------
	Function Name :	int16 HW_One_PI(int16 Xn1, int16 Yn0, int16 Xn2)
	Description   :	PI控制
	Input         :	Xn1--E(K)
	Output		  :	PI_UK--当前PI输出值,执行时间us
-------------------------------------------------------------------------------------------------*/
//int16 HW_One_PI(int16 Xn1)
//{
//	  PI_EK =  Xn1;	      //填入EK
//	  PI_LPF_CR |= 0x02;	  // Start PI
//	  _nop_();  _nop_();  _nop_();  _nop_();  _nop_();
//	  PI_UK+=(SKP/4096 +1);
//	  return PI_UK;
//}

/*-------------------------------------------------------------------------------------------------
	Function Name :	int16 LPF(int16 Xn1, int16 Xn0, int8 K)
	Description   :	LFP控制
	Input         :	Xn1--当前输入值
	                Xn0--上一次滤波输出值
									K--LPF滤波系数
  Output				:	LPF_Y--当前滤波输出值，执行时间为4us。
-------------------------------------------------------------------------------------------------*/
int16 LPFFunction(int16 Xn1, int16 Xn0, int8 K)
{
	LPF_K = K;
	LPF_X = Xn1;
	LPF_Y = Xn0;
	SetBit(PI_LPF_CR, LPFSTA);
	_nop_();_nop_();_nop_();_nop_();_nop_();_nop_();_nop_();
	return LPF_Y;
}


/*---------------------------------------------------------------------------*/
/* Name		:	void Sleepmode(void)
/* Input	:	NO
/* Output	:	NO
/* Description:	睡眠模式测试
/*---------------------------------------------------------------------------*/
 void Sleepmode(void)
 {
	 	SleepSet.SleepDelayCout++;
		if(SleepSet.SleepDelayCout>=20000)//最大65530，若要再大，需改数据类型
		{
//				FOC_EFREQMIN 	= -Motor_Omega_Ramp_Min;
//				FOC_EFREQHOLD = -Motor_Omega_Ramp_End;
			mcSpeedRamp.TargetValue=0;
			MOE     = 0;
			ClrBit(DRV_CR, FOCEN);	//关闭FOC
			SleepSet.SleepDelayCout=0;
			SleepSet.SleepFlag=1;
			SetBit(P1_IE, P11);   // config P11 as the source of EXTI1
			SetBit(PCON, STOP);
		}
 }

 
/*---------------------------------------------------------------------------*/
/* Name		:	void ONOFFControl (void)
/* Input	:	NO
/* Output	:	NO
/* Description:
/*---------------------------------------------------------------------------*/
void ONOFFControl (void)
{
	static uint8 MotorONFilterTimer=0;
	static uint8 MotorOFFFilterTimer=0;

	
    /* Speed_response is the sole owner of throttle/run requests. */
    if (!LV_BOARD_POWER_STAGE_VERIFIED || McuOverTempLatched || BoardOverCurrentLatched ||
        mcFaultSource != FaultNoSource || mcState == mcFault)
    {
        MOE = 0;
        mcFocCtrl.MotorONOFFStatus = 0;
        return;
    }
	if((mcFocCtrl.MotorONOFFStatus)&&(mcState == mcStop)&&(mcState != mcFault)&&(!mcFocCtrl.FlagmcBrake ))
	{
		MotorONFilterTimer++;

		if(MotorONFilterTimer>10)
		{
			if(mcFocCtrl.FreeStopDecStatus)				
			{
				mcState = mcRun;
			}
			else
			{	
				mcState = mcInit;		
			}
			
			MotorONFilterTimer=0;
		}
	}
	else
	{
		MotorONFilterTimer=0;
	}
			
	if((!mcFocCtrl.MotorONOFFStatus)&&(mcState != mcStop)&&(!mcFocCtrl.LockedFlag)&&(!mcFocCtrl.LockedEnbleFlag))
	{			
		MotorOFFFilterTimer++;
		
		if(MotorOFFFilterTimer>5)
		{
			MotorOFFFilterTimer =0;
			
			mcState = mcStop;	
						
			mcFocCtrl.mcStopMode = MotorStopMode;

		}
	}
	else
	{
		MotorOFFFilterTimer = 0;
	}
}

/*-------------------------------------------------------------------------------------------------
	Function Name :	void Hall_RTHESTEP_Capture(void)
	Description   :	
	Input         :	               
  Output				:	速度计算
-------------------------------------------------------------------------------------------------*/
void Hall_RTHESTEP_Capture(void)
{	
	static uint8 BaseFlag = 0 ;
	++speedHallEdges;
	if(mcHall.HallSpeedInitStatus == 0)
	{
		mcHall.StepTimeCount           = 0;	
						
		mcHall.MC_StepTime[0] = 0;
		mcHall.MC_StepTime[1] = 0;
		mcHall.MC_StepTime[2] = 0;
		mcHall.MC_StepTime[3] = 0;
		mcHall.MC_StepTime[4] = 0;
		mcHall.MC_StepTime[5] = 0;
							
		mcHall.FlagSpeedCal =0;
				
		mcHall.RTheStep      = 0;	
		
		mcHall.HallSpeedInitStatus =1;
		
	}
	else
	{

		mcHall.MC_StepTime[mcHall.HallStatus_Result-1] = TIM4__CNTR; 

		TIM4__CNTR = 0;
										
		if(mcHall.HallCommutationCount <= 6)
		{
			mcHall.HallThetaBase        = TempHallThetaBaseOneStep * mcHall.HallCommutationCount;//TEMPHallThetaBaseOneStep[mcHall.HallCommutationCount-1];
			
			mcHall.HallSpeedBase        = TempHallSpeedBaseOneStep * mcHall.HallCommutationCount;//TEMPHallSpeedBaseOneStep[mcHall.HallCommutationCount-1];
			
			BaseFlag =0;
			
			mcHall.FlagSpeedCal = 1;
		} 
		else if((mcHall.HallCommutationCount > 6)&&(BaseFlag==0))	
		{
			mcHall.HallThetaBase = TempHallThetaBase;
			
			mcHall.HallSpeedBase = TempHallSpeedBase;		
			
			BaseFlag = 1;							
		}
					
		mcHall.PeriodTime = mcHall.MC_StepTime[0] + mcHall.MC_StepTime[1] + mcHall.MC_StepTime[2] + mcHall.MC_StepTime[3] + mcHall.MC_StepTime[4] + mcHall.MC_StepTime[5]; 	//5.4us
	
		if(mcHall.HallStatus_Result==6)
		{				
			mcHall.FlagSpeedCal = 1;
		}

//		MDUAPP1();  
				
		FOC__RTHESTEP  = mcHall.RTheStep;	 	

		if(FOC__RTHESTEP>16385)
		{
			FOC__RTHESTEP = 10;
		}
			
	}
}


/*-------------------------------------------------------------------------------------------------
	Function Name :	int16 RampControl(Ramp_TypeDef *Ramp, int16 Ref)
	Description   :	爬坡目标函数，根据设定爬坡增量把当前值向目标值靠拢
	Input         :	Ramp--爬坡对象数组
                  Ref-- 爬坡参考值
  Output				:	RampStep--爬坡当前输出
-------------------------------------------------------------------------------------------------*/
uint16 RampControl(Ramp_TypeDef *Ramp, uint16 Ref)
{
	Ramp->RampTarget = Ref;
	if(Ramp->RampTarget > Ramp->RampStep)
	{
		if((Ramp->RampStep + Ramp->RampInc) <= Ramp->RampTarget)
		{
			Ramp->RampStep += Ramp->RampInc;
		}
		else
		{
			Ramp->RampStep = Ramp->RampTarget;
		}
	}
	else if(Ramp->RampTarget < Ramp->RampStep)
	{
		if((Ramp->RampStep - Ramp->RampDec) >= Ramp->RampTarget)
		{
			Ramp->RampStep -= Ramp->RampDec;
		}
		else
		{
			Ramp->RampStep = Ramp->RampTarget;
		}
	}	
	return 	Ramp->RampStep;
}

/*---------------------------------------------------------------------------*/
/* Name		:	void MotorStop(void)
/* Input	:	NO
/* Output	:	NO
/* Description:
/*---------------------------------------------------------------------------*/
void MotorStop(void)
{	
	if(mcFocCtrl.mcStopMode == FreeStop)
	{
		mcFocCtrl.CurrentStopMode = FreeStop;
	}
	else if((mcFocCtrl.mcStopMode == QuickBrakeStop)||(mcFocCtrl.mcStopMode == SlowBrakeStop))   
	{
		mcFocCtrl.CurrentStopMode = mcFocCtrl.mcStopMode;
	}
	else if(mcFocCtrl.mcStopMode == SlowStop)   
	{
		mcFocCtrl.CurrentStopMode = SlowStop;
	}

	if(mcFocCtrl.CurrentStopMode == FreeStop)
	{					
			FOC_CR1 = 0x00;
			MOE = 0;
			/*关闭FOC*/
			ClrBit(DRV_CR, FOCEN);						
	}
	else if((mcFocCtrl.CurrentStopMode == QuickBrakeStop)||(mcFocCtrl.CurrentStopMode == SlowBrakeStop))
	{			
		if(mcFocCtrl.CurrentStopMode == QuickBrakeStop)
		{
			DRV_DR = 0.3*DRV_ARR;				      // brake PWM DUTY			
    }
		else if(mcFocCtrl.CurrentStopMode == SlowBrakeStop)
		{			
			DRV_DR = mcFocCtrl.BrakeDuty*DRV_ARR;				    // brake PWM DUTY	
    }	
		
		mcFocCtrl.mcIqref =0;
		SpeedRamp.SPEEDRampCnt = 0;
		SpeedRamp.RampStep = 	mcFocCtrl.mcIqref;
		FOC_QMAX		= SpeedRamp.RampStep;
		FOC_QMIN		= SpeedRamp.RampStep;
					
		DRV_CMR |= 0x15;
		
		ClrBit(DRV_CR,OCS);        //OCS = 0, DRV_COMR;OCS = 1, FOC/SVPWM/SPWM
			       
		SetBit(DRV_CR, FOCEN);			
		MOE	= 1;
		
	}
}

/*---------------------------------------------------------------------------*/
/* Name		:	void mcTailWindDispose (void)
/* Input	:	NO
/* Output	:	NO
/* Description: 速度跟随处理
/*---------------------------------------------------------------------------*/
void  mcTailWindDispose (void)
{
	int16 TempCalCulFOC_QM;
	
		if((mcState== mcRun)||(mcState== mcStart))
		{									
			if(mcHall.HallDirectStartStatus)
			{
				if((Time.mcRunStateCount<60000)&&(Time.mcRunStateCount!=1))
				{
					Time.mcRunStateCount++;
				}
				
				if(Time.mcRunStateCount>50)
				{
					MOE = 1;
					
          //输出占空比递增				
					SpeedFollow(560,QOUTMAX,QOUTMIN);  // SRampInc 爬坡增量 327 - 1638
																	
					if(Time.mcRunStateCount>100)
					{
						mcHall.HallDirectStartStatus =0;																	
					}
				}
				else if(Time.mcRunStateCount==1)
				{																
						mcFocCtrl.SpeedV_k = mcHall.LastHallSpeed/20000.0;
					 					
						if(mcHall.LastHallSpeed <= 1200)
						{
							TempCalCulFOC_QM = 	_Q15(0.2)*mcFocCtrl.SpeedV_k +_Q15(0.1);	
						} 
						else  if(mcHall.LastHallSpeed <= 1800)
						{
							TempCalCulFOC_QM = 	_Q15(0.4)*mcFocCtrl.SpeedV_k +_Q15(0.3);	
						} 
						else 
						{
							TempCalCulFOC_QM = 	_Q15(0.7)*mcFocCtrl.SpeedV_k +_Q15(0.6);	
						}  
												
						FOCQMAXLimit(TempCalCulFOC_QM); 	    //输出占空比赋值	              	
					
						SpeedRamp.RampStep = TempCalCulFOC_QM;
						
						FOC__UQ = SpeedRamp.RampStep;
										 					
						mcHall.HallCommutationCount=1;
					
						Time.mcRunStateCount =2;				
				}
			}
			else
			{
				Time.mcRunStateCount=0;
			}			
		}
}


/*---------------------------------------------------------------------------*/
/* Name		:	void RMSCurrentLimit (void)
/* Input	:	NO
/* Output	:	NO
/* Description: 均值限流处理
/*---------------------------------------------------------------------------*/
void RMSCurrentLimit(void)
{
	static uint16 OverLimitCurrentTimeUPCnt = 0;

	if(mcFocCtrl.mcADCCurrentbus >= (mcFocCtrl.RMSLimitTargetCurrent+50))
	{	
		if(mcFocCtrl.mcIqref>50)
		{
			mcFocCtrl.mcIqref -=50;							
		}
		
		FOC__UQ = mcFocCtrl.mcIqref;

		SpeedRamp.RampStep = mcFocCtrl.mcIqref;	
	}
	
	if(mcFocCtrl.mcADCCurrentbus >= (mcFocCtrl.RMSLimitTargetCurrent))
	{	
		if(mcFocCtrl.mcIqref>10)
		{
			mcFocCtrl.mcIqref -=10;							
		}
		
		FOC__UQ = mcFocCtrl.mcIqref;

		SpeedRamp.RampStep = mcFocCtrl.mcIqref;	
	}
	
	
//	else if(mcFocCtrl.mcADCCurrentbus <= (mcFocCtrl.RMSLimitTargetCurrent>>1))
//	{
//		if(OverLimitCurrentTimeUPCnt>0)
//		{
//			OverLimitCurrentTimeUPCnt--;
//		}
//		
//		OverLimitCurrentTimeDownCnt++;
//		
//		if(OverLimitCurrentTimeDownCnt > 20000)
//		{
//			PI_KP = VKP;
//			PI_KI = VKI;

//			PI_UKMAX = SOUTMAX;
//			PI_UKMIN = SOUTMIN;
//			
//			Limit_Flag =0;
//			mcFocCtrl.RMSLimitCurrentFlag =0;   //均值限流标志位清0
//		  OverLimitCurrentTimeDownCnt = 0;
//		}	
//	}
	
}

/*---------------------------------------------------------------------------*/
/* Name		:	void HallLockDisposeFuntion (void)
/* Input	:	NO
/* Output	:	NO
/* Description: 堵转保护检测
/*---------------------------------------------------------------------------*/
void HallLockCheckFuntion (void)
{
	if(mcHall.HALLLockStatus)
	{
		mcHall.mcStallTimeCnt++;
		
		if(mcHall.mcStallTimeCnt >= StallTime)
		{
			mcHall.mcStallTimeCnt = StallTime;
    }
  }
	else
	{
		mcHall.mcStallTimeCnt =0;
  }
		
	if(HALLC)
	{
		mcHall.HALLHCCWCCWTime ++;
		
		#if (StallProtectEnable)
		{
			if((mcState == mcRun)||(mcState == mcStart))
			{				
				mcHall.HALLLockHCTime++;
				if(mcHall.HALLLockHCTime>=StallDetectTime)
				{
					mcHall.HALLLockHCTime = StallDetectTime;
					mcHall.HALLLockStatus = 1;					
				}
			}
		}
		#endif
	}
	else
	{
		mcHall.HALLLockHCTime = 0;
		mcHall.HALLHCCWCCWTime =0;
	}
	
	
	if(HALLB)
	{
		mcHall.HALLHBCWCCWTime ++;
		
		#if (StallProtectEnable)
		{
			if((mcState == mcRun)||(mcState == mcStart))
			{				
				mcHall.HALLLockHBTime++;
				if(mcHall.HALLLockHBTime>=StallDetectTime)
				{
					mcHall.HALLLockHBTime = StallDetectTime;
					mcHall.HALLLockStatus =1;
				}
			}
		}
		#endif
	}
	else
	{
		mcHall.HALLLockHBTime = 0;
		mcHall.HALLHBCWCCWTime =0;
	}
	
	if(HALLA)
	{
		mcHall.HALLHACWCCWTime++;
		
		#if (StallProtectEnable)
		{
			if((mcState == mcRun)||(mcState == mcStart))
			{				
				mcHall.HALLLockHATime++;
				if(mcHall.HALLLockHATime >= StallDetectTime)
				{
					mcHall.HALLLockHATime = StallDetectTime;
					mcHall.HALLLockStatus = 1;
				}
			}
		}
		#endif
	}
	else
	{
		mcHall.HALLLockHATime = 0;
		mcHall.HALLHACWCCWTime =0;
	}
}

/*---------------------------------------------------------------------------*/
/* Name		:	void Hall_THETA_Capture (void)
/* Input	:	NO
/* Output	:	NO
/* Description: 角度处理
/*---------------------------------------------------------------------------*/
void Hall_THETA_Capture(void)  
{
	static int16 data TempHall_Angle = 0;
	
	TempHall_Angle = ThetaDispose (mcHall.HallStatus_Result,mcHall.GivenFRStatus,TempAngleOffsetCW,TempAngleOffsetCCW,mcHall.AngleCompensate); //10us

	FOC__THETA     = TempHall_Angle;
	
	mcHall.NextSectorAngle = TempHall_Angle + 10922;  	
}

/*---------------------------------------------------------------------------*/
/* Name		:	void StartThetaDispose (uint8 Hall_Status_Result,uint8 GivenFR_Status,uint16 TempAngle_OffsetCW,int16 TempAngle_OffsetCCW,int16 StartAngle_Offset)
/* Input	:	Hall_Status_Result 霍尔信号; GivenFR_Status 电机方向;
						TempAngle_OffsetCW CW方向的偏移角度;TempAngle_OffsetCCW CCW方向的偏移角度;StartAngle_Offset 启动角度
/* Output	:	
/* Description:	
/*---------------------------------------------------------------------------*/
int16 StartThetaDispose (uint8 Hall_Status_Result,uint8 GivenFR_Status,int16 TempAngle_OffsetCW,int16 TempAngle_OffsetCCW,int16 StartAngle_Offset)
{	
	 int16 MCFoc_theta = 0 ;
	
	 int16 Hall_Angle = 0;
	
	 int16 TempHallAngle = 0;
	
	Hall_Angle            = Hall_Angle_Arr[Hall_Status_Result-1];
	
	if(GivenFR_Status == CW)
	{
		TempHallAngle  = Hall_Angle + TempAngle_OffsetCW  + StartAngle_Offset;
	}
	else if(GivenFR_Status == CCW)		
	{					
		TempHallAngle = Hall_Angle + TempAngle_OffsetCCW + StartAngle_Offset;
		
		TempHallAngle =(0 - TempHallAngle);										
	}
	
	MCFoc_theta = (int16)TempHallAngle;
	
	return MCFoc_theta ;
}

/*---------------------------------------------------------------------------*/
/* Name		:	int16 ThetaDispose (uint8 Hall_Status_Result,uint8 GivenFR_Status,uint16 TempAngle_OffsetCW,int16 TempAngle_OffsetCCW,int16 Angle_Compensate,int16 StartAngle_Offset)
/* Input	:	Hall_Status_Result 霍尔信号; GivenFR_Status 电机方向;
						TempAngle_OffsetCW CW方向的偏移角度;TempAngle_OffsetCCW CCW方向的偏移角度;Angle_Compensate 补偿角度
						
/* Output	:	
/* Description:	
/*---------------------------------------------------------------------------*/
int16 ThetaDispose (uint8 Hall_Status_Result,uint8 GivenFR_Status,int16 TempAngle_OffsetCW,int16 TempAngle_OffsetCCW,int16 Angle_Compensate)
{
	 int16 Hall_Angle = 0;
	
	 int16 TempHallAngle = 0;
	
	Hall_Angle            = Hall_Angle_Arr[Hall_Status_Result-1];
	
	if(GivenFR_Status == CW)
	{
		TempHallAngle  = Hall_Angle + TempAngle_OffsetCW + Angle_Compensate ;//+ StartAngle_Offset;
	}
	else if(GivenFR_Status == CCW)		
	{					
		TempHallAngle = Hall_Angle + TempAngle_OffsetCCW ;//+ StartAngle_Offset;
		
		TempHallAngle =((0 - TempHallAngle)+ Angle_Compensate);										
	}
		
	return TempHallAngle;
}

/*---------------------------------------------------------------------------*/
/* Name		:	void FocRtheStep_Control (int16 RThe_Step)
/* Input	:	RThe_Step 角速度
/* Output	:	
/* Description:	
/*---------------------------------------------------------------------------*/
void FocRtheStep_Control (int16 RThe_Step)
{
	FOC__RTHESTEP  = RThe_Step;			
}

/*---------------------------------------------------------------------------*/
/* Name		:	extern void SpeedFollow(uint16 SRampInc)
/* Input	:	
						
/* Output	:	
/* Description:	
/*---------------------------------------------------------------------------*/
void SpeedFollow(uint16 SRampInc,int16 MaxDuty,int16 MinDuty)
{
	static int16 TempFOC_QMAX;
	static int16 TempFOC_QMIN;
	
		TempFOC_QMAX = (int16)FOC_QMAX;
		TempFOC_QMIN = (int16)FOC_QMIN;
		
		if(TempFOC_QMAX < MaxDuty)
		{
			TempFOC_QMAX+=SRampInc;//_Q15(0.03);
		}		
		else		
		{
			TempFOC_QMAX = MaxDuty;
		}		
		
		if(TempFOC_QMIN>MinDuty)
		{
			TempFOC_QMIN-=SRampInc;//_Q15(0.03);
		}
		else
		{
			TempFOC_QMIN = MinDuty;
		}
		
		FOC_QMAX = TempFOC_QMAX;
		FOC_QMIN = TempFOC_QMIN;
		
}

/*---------------------------------------------------------------------------*/
/* Name		:	void FOCQMAXLimit (int16 TempQM)
/* Input	:	ÎÞ
/* Output	:	ÎÞ
/* Description:	
/*---------------------------------------------------------------------------*/
void FOCQMAXLimit (int16 TempQM)
{
	if((TempQM	<= QOUTMAX)&&(0<=TempQM))
	{
		FOC_QMAX	= 	TempQM;									  		
		FOC_QMIN	= 	TempQM;
	}	
	else
	{
		FOC_QMAX	= 	QOUTMAX;									  		
		FOC_QMIN	= 	QOUTMAX;
	}	
}

/*---------------------------------------------------------------------------*/
/* Name		:	uint8  HALLSignalDisposeWithoutFilter(uint16 Hall_CommutationCount,uint8 GivenFR_Status,uint8 HA,uint8 HB,uint8 HC)
/* Input	:	
/* Output	:	
/* Description:	
/*---------------------------------------------------------------------------*/

uint8  HALLSignalDisposeWithoutFilter(uint16 Hall_CommutationCount,uint8 GivenFR_Status,uint8 HA,uint8 HB,uint8 HC)
{	
		uint8 HallStatus = 0;
	
		static uint8  H_A = 0;
		static uint8  H_B = 0;
		static uint8  H_C = 0;
		
		H_A = HA;
		H_B = HB;
		H_C = HC;
							
		if(H_C)
		{
			HallStatus += 4;
		}
		
		if(H_B)
		{
			HallStatus += 2;
		}
		
		if(H_A)
		{
			HallStatus += 1;
		}

		return HallStatus;
}

/*---------------------------------------------------------------------------*/
/* Name		:	 void SamplingPrepare(void)
/* Input	:		无			
/* Output	:	  无
/* Description:	电流采样准备 
/*---------------------------------------------------------------------------*/
void SamplingPrepare(void)
{
		DRV_DR = 1.0*DRV_ARR;				      // brake PWM DUTY				
				
		DRV_CMR |= 0x15;
		
		ClrBit(DRV_CR,OCS);        //OCS = 0, DRV_COMR;OCS = 1, FOC/SVPWM/SPWM
			       
		SetBit(DRV_CR, FOCEN);	
	
		MOE	= 1;   	
}
