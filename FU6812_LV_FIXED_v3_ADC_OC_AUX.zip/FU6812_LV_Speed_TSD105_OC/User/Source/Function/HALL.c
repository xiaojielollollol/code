/**************************** (C) COPYRIGHT 2017 Fortiortech shenzhen *****************************
* File Name          : AddFunction.c
* Author             : Vina Peng,Fortiortech  Appliction Team
* Version            : V1.0
* Date               : 10-Apr-2017
* Description        : This file contains MDU initial function used for Motor Control.
***************************************************************************************************
* All Rights Reserved
**************************************************************************************************/


/* Includes -------------------------------------------------------------------------------------*/
#include <FU68xx_2.h>
#include <Myproject.h>

//HALL �ͺ󷴵綯��25��// �����ͷ��綯�Ƽ�����ͬ   //5->1->3->2->6->4   0��->60��->120��->180��->240��->300��
int16 xdata Hall_Angle_Arr[6] = {_Q15(60.0/180.0),_Q15(180.0/180.0),_Q15(120.0/180.0),_Q15(300.0/180.0),_Q15(0.0/180.0),_Q15(240.0/180.0)};	

/*---------------------------------------------------------------------------*/
/* Name		:	uint8  HallCommutation(uint8 GivenFR_Status ,uint8 Hall_Status_Result )
/* Input	:	GivenFR_Status ��ǰ����Hall_Status_Result��ǰhall�ź�
/* Output	:	Hall_Status_Next ��һ��hall�ź�
/* Description:	
/*---------------------------------------------------------------------------*/
uint8  HallCommutation(uint8 GivenFR_Status ,uint8 Hall_Status_Result)
{
	static uint8 data Hall_Status_Next = 0;
   	//CW  5->1->3->2->6->4
		if(GivenFR_Status == CW)
		{	
				switch(Hall_Status_Result)
				{
					case 1:
						Hall_Status_Next = 3;
						break;
					case 2:
						Hall_Status_Next = 6;
						break;
					case 3:
						Hall_Status_Next = 2;
						break;
					case 4:
						Hall_Status_Next = 5;
						break;
					case 5:
						Hall_Status_Next = 1;
						break;
					case 6:
						Hall_Status_Next = 4;
						break;
					default:
						break;
				 }
		 }		 
		//CCW 5->4->6->2->3->1
		if(GivenFR_Status == CCW)
		{
			switch(Hall_Status_Result)
			{
				case 1:
				  Hall_Status_Next = 5;
					break;
				case 2:
				  Hall_Status_Next = 3;
					break;
				case 3:
				  Hall_Status_Next = 1;
					break;
				case 4:
				  Hall_Status_Next = 6;
					break;
				case 5:
				  Hall_Status_Next = 4;
					break;
				case 6:
				  Hall_Status_Next = 2;
					break;
				default:
					break;
			}
		}
		return Hall_Status_Next;
}


void HallStatus_CaptureFilter(void)
{
//	mcHall.HallStatus_Filter2    = mcHall.HallStatus_Filter1;	

	mcHall.HallStatus_Filter1    = HALLSignalDisposeWithoutFilter(mcHall.HallCommutationCount,mcHall.GivenFRStatus,HALLA,HALLB,HALLC);  

//	 if((mcHall.HallStatus_Filter1  == mcHall.HallStatus_Filter2)
//		 &&(mcHall.HallStatus_Filter2 != 0))
//	 {
//		 mcHall.HallStatus_Result = mcHall.HallStatus_Filter2;
//	 }
//   else if(mcHall.HallStatus_Filter2==0)
//	 {
		 mcHall.HallStatus_Result = mcHall.HallStatus_Filter1;
//   }		 
}

void HallTimeCapture(void)
{
//	GP01 =1;
	
	Hall_RTHESTEP_Capture();  //�ٶȼ��㼰���ٶȴ��� 7us
	
//	GP01 =0;	
	

	Hall_THETA_Capture();	    //�Ƕȴ��� 14.6us	

	
}

