/**************************** (C) COPYRIGHT 2017 Fortiortech shenzhen *****************************
* File Name          : AddFunction.c
* Author             : Vina Peng,Fortiortech  Appliction Team
* Version            : V1.0
* Date               : 10-Apr-2017
* Description        : This file contains MDU initial function used for Motor Control.
***************************************************************************************************
* All Rights Reserved
**************************************************************************************************/


/* Includes -------------------------------------------------------------------------------------*/
#include <FU68xx_2.h>
#include <Myproject.h>

//MDUControl_TypeDef xdata MDUControl;

/*-------------------------------------------------------------------------------------------------
	Function Name : void MDUAPP1(void)
	Description   :
	Input         :	��
  Output				:	��
-------------------------------------------------------------------------------------------------*/
void MDUAPP1(void)
{
//	static uint16 idata TempPeriodTime =0;
	
//	static uint8 MDUCountCnt =0;
	
//	volatile uint16 TempPeriodTime =0;
	
	if(mcHall.FlagSpeedCal)//&&(mcHall.MDUCountFlag))
	{		
//		TempPeriodTime = mcHall.PeriodTime;
		
//		mcHall.RTheStep  =  MDU_DIV_IDATA_U32(&mcHall.HallThetaBase, &mcHall.PeriodTime);	
		
//		mcHall.HallSpeed = MDU_DIV_IDATA_U32(&mcHall.HallSpeedBase, &mcHall.PeriodTime);	
		
		mcHall.RTheStep = mcHall.HallThetaBase/mcHall.PeriodTime;
//		
		mcHall.HallSpeed	= mcHall.HallSpeedBase/mcHall.PeriodTime;
		
//		if(mcHall.MDUCountCnt==0)
//		{
//			mcHall.RTheStep = mcHall.HallThetaBase/mcHall.PeriodTime;// MDU_DIV_IDATA_U32(&mcHall.HallThetaBase, &mcHall.PeriodTime);	
//			
////			if(ReadBit(MDU_CR, DIVDONE))
////			{
////				mcHall.MDUCountCnt =1;	
////			}
//    }
//						
// 		if(mcHall.MDUCountCnt==1)
//		{			
//			mcHall.HallSpeed	= mcHall.HallSpeedBase/mcHall.PeriodTime;//MDU_DIV_IDATA_U32(&mcHall.HallSpeedBase, &mcHall.PeriodTime);	
//			
////			if(mcHall.MDUCountCnt)
////			{
////				mcHall.MDUCountCnt =0;	
////				
////				mcHall.FlagSpeedCal = 0;	
////			}
//		}
//		
//		if(mcHall.MDUCountCnt==2)
//		{
//			mcHall.MDUCountCnt =0;	
//			
//			mcHall.FlagSpeedCal = 0;	
//		}
//		

//		if(MDUCountCnt>=2)
//		{
//			MDUCountCnt =0;
//			
//			mcHall.FlagSpeedCal = 0;	
//		}
//						
		mcHall.FlagSpeedCal = 0;	
	}			
}









