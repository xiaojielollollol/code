from pathlib import Path
import tempfile,subprocess,os,re
root=Path(__file__).resolve().parents[1]
mcu=(root/'Library/FU68xx_Hardware_Driver/Include/FU68xx_2_MCU.h').read_text(encoding='utf-8-sig')
defines=''
for name in ('FOCEN','ADCEN','ADCBSY'):
    m=re.search(r'^\s*#define\s+'+name+r'\s+(0x[0-9a-fA-F]+)',mcu,re.M);assert m,name
    defines+='#define '+name+' '+m[1]+'\n'
stub=r'''
#include <stdint.h>
typedef uint8_t uint8;
typedef uint16_t uint16;
#define xdata
#define SetBit(r,b) ((r)|=(b))
#define ClrBit(r,b) ((r)&=(uint8)~(b))
#define ReadBit(r,b) (((r)&(b))==(b))
extern uint8 MOE,DRV_CR,ADC_CR,mcFaultSource,mcState;
extern uint16 ADC10_DR;
'''
project=r'''
#include "Customer.h"
enum {FaultNoSource=0,FaultSoftOVCurrent=2,FaultAdcSampleTimeout=12,mcFault=99};
typedef struct {uint8 MotorONOFFStatus;} MockMotor;
extern MockMotor mcFocCtrl;
'''
test=r'''
#include <assert.h>
#include <stdlib.h>
#include <stdio.h>
#include "FU68xx_2.h"
#include "Myproject.h"
#include "BoardOverCurrent.h"
uint8 MOE=1,DRV_CR=255,ADC_CR=ADCEN,mcFaultSource,mcState;
uint16 ADC10_DR;
MockMotor mcFocCtrl={1};
int main(int argc,char **argv) {
 int i;int mode=argc>1?atoi(argv[1]):0;
 assert(BOARD_OC_TRIP_RAW==741);
 if(mode==0) {
  ADC10_DR=4095;BoardOc_Service();
  assert(!BoardOverCurrentLatched && !BoardOcAdcReady);
  assert(ReadBit(ADC_CR,ADCBSY));
  BoardOc_Service();assert(!BoardOverCurrentLatched && !BoardOcAdcReady);
  ADC_CR&=(uint8)~ADCBSY;ADC10_DR=740;BoardOc_Service();
  assert(BoardOcAdcReady && BoardOcAdcRaw==740 && !BoardOverCurrentLatched);
  ADC_CR&=(uint8)~ADCBSY;ADC10_DR=741;BoardOc_Service();
  assert(BoardOverCurrentLatched && BoardOcFaultCode==FaultSoftOVCurrent);
  assert(!MOE && !(DRV_CR&FOCEN) && !mcFocCtrl.MotorONOFFStatus && mcState==mcFault);
  ADC10_DR=0;MOE=1;DRV_CR=255;BoardOc_Service();
  assert(BoardOverCurrentLatched && !MOE && !(DRV_CR&FOCEN));
 } else if(mode==1) {
  BoardOc_Service();for(i=0;i<BOARD_OC_ADC_TIMEOUT_CALLS;i++)BoardOc_Service();
  assert(BoardOverCurrentLatched && BoardOcFaultCode==FaultAdcSampleTimeout && !MOE);
 } else if(mode==2) {
  ADC_CR|=ADCBSY;for(i=0;i<BOARD_OC_ADC_TIMEOUT_CALLS;i++)BoardOc_Service();
  assert(BoardOverCurrentLatched && BoardOcFaultCode==FaultAdcSampleTimeout && !MOE);
 } else {
  ADC_CR=0;BoardOc_Service();assert(BoardOverCurrentLatched && !MOE);
 }
 puts("PASS: auxiliary ADC overcurrent scenario");return 0;
}
'''
with tempfile.TemporaryDirectory() as d:
    w=Path(d)
    (w/'FU68xx_2.h').write_text('#ifndef MOCK_MCU\n#define MOCK_MCU\n'+stub+defines+'\n#endif\n')
    (w/'Myproject.h').write_text('#ifndef MOCK_PROJECT\n#define MOCK_PROJECT\n'+project+'\n#endif\n')
    (w/'test.c').write_text(test)
    subprocess.run(['gcc','-std=gnu89','-Wall','-Wextra','-Werror','-Wdeclaration-after-statement',
       '-fsanitize=undefined,address','-g','-I'+str(w),'-I'+str(root/'User/Include'),
       str(root/'User/Source/Application/BoardOverCurrent.c'),str(w/'test.c'),'-o',str(w/'test')],check=True)
    env=dict(os.environ);env['ASAN_OPTIONS']='detect_leaks=0'
    for mode in range(4):subprocess.run([str(w/'test'),str(mode)],check=True,env=env)
