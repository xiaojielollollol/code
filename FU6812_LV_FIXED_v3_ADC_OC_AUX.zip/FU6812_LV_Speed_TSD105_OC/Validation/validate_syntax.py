from pathlib import Path
import re,shutil,subprocess,tempfile
src=Path(__file__).resolve().parents[1]
dst=Path(tempfile.mkdtemp(prefix='fu6812-syntax-'))
dst.mkdir(exist_ok=True)
for p in src.rglob('*'):
    if not p.is_file() or p.suffix.lower() not in ('.c','.h'):continue
    if 'KeilC51' in p.parts:continue
    data=p.read_bytes()
    for e in ('utf-8-sig','gb18030'):
        try:t=data.decode(e);break
        except UnicodeDecodeError:pass
    t=re.sub(r'^\s*sfr\s+(\w+)\s*=.*?;',r'extern volatile unsigned char \1;',t,flags=re.M)
    t=re.sub(r'^\s*sfr16\s+(\w+)\s*=.*?;',r'extern volatile unsigned short \1;',t,flags=re.M)
    t=re.sub(r'^\s*sbit\s+(\w+)\s*=.*?;',r'extern volatile unsigned char \1;',t,flags=re.M)
    t=re.sub(r'\binterrupt\s+\d+','',t)
    t=re.sub(r'\busing\s+\d+','',t)
    # Case-insensitive includes are supported on the user's Windows machine.
    t=re.sub(r'(#include\s*[<"])([^>"\n]+)',lambda m:m[1]+m[2].lower(),t)
    q=dst/p.relative_to(src);q=q.with_name(q.name.lower());q.parent.mkdir(parents=True,exist_ok=True);q.write_text(t)
stubs=dst/'stubs';stubs.mkdir(exist_ok=True)
(stubs/'absacc.h').write_text('')
(stubs/'intrins.h').write_text('extern void _nop_(void);\nextern unsigned char _crol_(unsigned char,unsigned char);\nextern unsigned char _cror_(unsigned char,unsigned char);\n')
includes=[stubs,dst/'User/Include',dst/'Library/FU68xx_Hardware_Driver/Include']
units=['User/Source/Application/boardovercurrent.c','User/Source/Application/main.c','User/Source/Application/addfunction.c',
 'User/Source/Application/interrupt.c','User/Source/Function/foccontrolfunction.c',
 'User/Source/Hardware/cmpinit.c','User/Source/Hardware/adcinit.c',
 'User/Source/Hardware/timerinit.c']
failures=0
for n in units:
    args=['gcc','-fsyntax-only','-std=gnu89','-fmax-errors=8','-w',
      '-Dxdata=','-Didata=','-Dcode=','-Ddata=','-Dbdata=','-Dpdata=',
      '-Dbit=unsigned char','-Dreentrant=']
    args += ['-I'+str(p) for p in includes]+[str(dst/n)]
    run=subprocess.run(args,capture_output=True,text=True)
    if run.returncode:failures+=1;print(n,run.stderr[:5000])
    else:print('HOST SYNTAX PASS',n)
print('Failed units:',failures)
shutil.rmtree(dst)
raise SystemExit(bool(failures))
